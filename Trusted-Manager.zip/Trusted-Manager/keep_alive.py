import time
import datetime
from flask import Flask, jsonify
from threading import Thread

app = Flask(__name__)

START_TIME = time.time()

@app.route('/')
def home():
    uptime_seconds = int(time.time() - START_TIME)
    hours, remainder = divmod(uptime_seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    uptime_str = f'{hours}h {minutes}m {seconds}s'
    return (
        f'<html><body style="font-family:sans-serif;text-align:center;padding:40px;background:#2c2f33;color:#fff">'
        f'<h1 style="color:#00C851">✅ Bot is Online</h1>'
        f'<p>Uptime: <strong>{uptime_str}</strong></p>'
        f'<p>Started: <strong>{datetime.datetime.utcfromtimestamp(START_TIME).strftime("%Y-%m-%d %H:%M:%S UTC")}</strong></p>'
        f'<p style="color:#aaa;font-size:12px">Ping this URL every 5 minutes via UptimeRobot to keep the bot online 24/7.</p>'
        f'</body></html>'
    )

@app.route('/ping')
def ping():
    return 'pong', 200

@app.route('/status')
def status():
    uptime_seconds = int(time.time() - START_TIME)
    return jsonify({
        'status': 'online',
        'uptime_seconds': uptime_seconds,
        'started_at': datetime.datetime.utcfromtimestamp(START_TIME).isoformat() + 'Z'
    })

def run():
    app.run(host='0.0.0.0', port=5000, use_reloader=False)

def keep_alive():
    t = Thread(target=run)
    t.daemon = True
    t.start()
