# main.py
# Discord bot with: invite tracking, leaderboard reset, embed helper, autoresponder,
# moderation (warn, mute, timeout, kick, ban), and giveaway system.

import discord
from discord.ext import commands, tasks
from discord import app_commands
import asyncio
import json
import os
from datetime import datetime, timedelta
import random
from typing import Optional
import re
from keep_alive import keep_alive

TOKEN = os.getenv('DISCORD_TOKEN')
PREFIX = '!'
INTENTS = discord.Intents.default()
INTENTS.members = True
INTENTS.message_content = True
INTENTS.guilds = True

bot = commands.Bot(command_prefix=PREFIX, intents=INTENTS, help_command=commands.DefaultHelpCommand())

DATA_DIR = 'data'
INVITES_FILE = os.path.join(DATA_DIR, 'invites.json')
WARNS_FILE = os.path.join(DATA_DIR, 'warns.json')
AUTORESPOND_FILE = os.path.join(DATA_DIR, 'autorespond.json')
GIVEAWAYS_FILE = os.path.join(DATA_DIR, 'giveaways.json')
ENDED_GIVEAWAYS_FILE = os.path.join(DATA_DIR, 'ended_giveaways.json')
INVITE_REWARDS_FILE = os.path.join(DATA_DIR, 'invite_rewards.json')
INVITE_ANALYTICS_FILE = os.path.join(DATA_DIR, 'invite_analytics.json')
ANTINUKE_FILE = os.path.join(DATA_DIR, 'antinuke.json')
AUTOMOD_FILE = os.path.join(DATA_DIR, 'automod.json')
POLLS_FILE = os.path.join(DATA_DIR, 'polls.json')
WELCOME_FILE = os.path.join(DATA_DIR, 'welcome.json')
TICKETS_FILE = os.path.join(DATA_DIR, 'tickets.json')
STAFF_ROLES_FILE = os.path.join(DATA_DIR, 'staff_roles.json')
BOT_PERMISSIONS_FILE = os.path.join(DATA_DIR, 'bot_permissions.json')
REVIEWS_FILE = os.path.join(DATA_DIR, 'reviews.json')
ORDERS_FILE = os.path.join(DATA_DIR, 'orders.json')

REVIEW_CHANNEL_ID = 1406413851511099462
ORDER_CHANNEL_ID = 1414673955725381773
ORDER_THUMBNAIL_GIF = 'https://media1.giphy.com/media/v1.Y2lkPTc5MGI3NjExdWEwZXRndTN2bXZ4aXh6aGFreml1YWhmbDkxaWdoYzZ1NWF4bTIyYyZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/6VbUf9AZju3M925zkA/giphy.gif'
ORDER_THUMBNAIL_PATH = 'assets/order_thumbnail.gif'
ORDER_THUMBNAIL_FILENAME = 'order_thumbnail.gif'

os.makedirs(DATA_DIR, exist_ok=True)

def load_json(path):
    if not os.path.exists(path):
        return {}
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def save_json(path, data):
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

invites_db = load_json(INVITES_FILE)
warns_db = load_json(WARNS_FILE)
autorespond_db = load_json(AUTORESPOND_FILE)
active_giveaways = load_json(GIVEAWAYS_FILE)
ended_giveaways_db = load_json(ENDED_GIVEAWAYS_FILE)
invite_rewards_db = load_json(INVITE_REWARDS_FILE)
invite_analytics_db = load_json(INVITE_ANALYTICS_FILE)
antinuke_db = load_json(ANTINUKE_FILE)
automod_db = load_json(AUTOMOD_FILE)
polls_db = load_json(POLLS_FILE)
welcome_db = load_json(WELCOME_FILE)
tickets_db = load_json(TICKETS_FILE)
staff_roles_db = load_json(STAFF_ROLES_FILE)
bot_permissions_db = load_json(BOT_PERMISSIONS_FILE)
reviews_db = load_json(REVIEWS_FILE)
orders_db = load_json(ORDERS_FILE)

guild_invite_cache = {}

# Permission system functions
def has_bot_permission(member: discord.Member) -> bool:
    """Check if a member has permission to use bot commands"""
    if member.guild_permissions.administrator:
        return True  # Admins always have access
    
    g = str(member.guild.id)
    allowed_roles = bot_permissions_db.get(g, [])
    
    if not allowed_roles:
        return True  # If no roles configured, everyone has access
    
    user_role_ids = [role.id for role in member.roles]
    return any(role_id in user_role_ids for role_id in allowed_roles)

def make_embed(title=None, description=None, color=0xff0000, footer=None):
    e = discord.Embed(title=title, description=description, color=color, timestamp=datetime.utcnow())
    if footer:
        e.set_footer(text=f'{footer}\nMade by Tanish14')
    else:
        e.set_footer(text='Made by Tanish14')
    return e

giveaway_task_started = False

@bot.event
async def on_ready():
    global giveaway_task_started
    if bot.user:
        print(f'Logged in as {bot.user} (ID: {bot.user.id})')
    else:
        print('Bot user is None')
    for guild in bot.guilds:
        try:
            invites = await guild.invites()
            guild_invite_cache[guild.id] = {inv.code: inv.uses for inv in invites}
        except discord.Forbidden:
            guild_invite_cache[guild.id] = {}
    for g in bot.guilds:
        invites_db.setdefault(str(g.id), {})
    save_json(INVITES_FILE, invites_db)
    if not giveaway_task_started:
        try:
            if not giveaway_checkpoint.is_running():
                giveaway_checkpoint.start()
        except RuntimeError:
            pass
        giveaway_task_started = True
    
    # Sync slash commands — guild sync first (instant), then global
    try:
        print('🔄 Starting command sync...')
        total_guild_synced = 0
        for guild in bot.guilds:
            try:
                guild_synced = await bot.tree.sync(guild=guild)
                total_guild_synced += len(guild_synced)
                print(f'✅ Guild sync: {len(guild_synced)} commands → {guild.name}')
            except Exception as ge:
                print(f'⚠️ Guild sync failed for {guild.name}: {ge}')

        synced = await bot.tree.sync()
        print(f'✅ Global sync: {len(synced)} slash command(s)')
        print('📋 Available slash commands:')
        for cmd in synced:
            print(f'  /{cmd.name} - {cmd.description}')
        print(f'🎯 Total commands synced: {len(synced)}')

        # Verify all expected commands are present
        expected_commands = [
            'mute', 'timeout', 'kick', 'ban', 'warn', 'warnings',
            'clearwarnings', 'removewarn',
            'invites', 'giveaway', 'greroll', 'automod',
            'help', 'reset', 'leaderboard',
            'staffadd', 'staffconfig', 'addrole', 'removerole',
            'purge', 'botpermissions', 'botpanel'
        ]

        synced_names = [cmd.name for cmd in synced]
        missing_commands = [cmd for cmd in expected_commands if cmd not in synced_names]
        if missing_commands:
            print(f'⚠️ Missing commands: {missing_commands}')
        else:
            print('✅ All expected commands are synced!')

    except Exception as e:
        print(f'❌ Failed to sync commands: {e}')
        import traceback
        traceback.print_exc()
    
    # Initialize invite cache for all guilds
    print('Initializing invite cache...')
    for guild in bot.guilds:
        try:
            invites = await guild.invites()
            guild_invite_cache[guild.id] = {inv.code: inv.uses for inv in invites}
            print(f'Cached {len(invites)} invites for {guild.name}')
        except discord.Forbidden:
            guild_invite_cache[guild.id] = {}
            print(f'No permission to view invites in {guild.name}')
        except Exception as e:
            print(f'Error caching invites for {guild.name}: {e}')
            guild_invite_cache[guild.id] = {}

    # Re-register button views for all active (non-expired) giveaways
    now = datetime.utcnow()
    for g_id, giveaways in active_giveaways.items():
        for msg_id_str, data in giveaways.items():
            try:
                end = datetime.fromisoformat(data['end_time'])
                if end > now:
                    view = make_giveaway_view(int(msg_id_str), int(g_id))
                    bot.add_view(view)
            except Exception:
                pass

@bot.event
async def on_guild_join(guild):
    try:
        invites = await guild.invites()
        guild_invite_cache[guild.id] = {inv.code: inv.uses for inv in invites}
        print(f'Cached {len(invites)} invites for new guild: {guild.name}')
    except discord.Forbidden:
        guild_invite_cache[guild.id] = {}
        print(f'No permission to view invites in {guild.name}')

@bot.event
async def on_member_remove(member):
    """Track when members leave to update invite stats"""
    guild = member.guild
    g = str(guild.id)
    
    # Update analytics
    invite_analytics_db.setdefault(g, {'total_joins': 0, 'total_leaves': 0, 'fake_detected': 0})
    invite_analytics_db[g]['total_leaves'] += 1
    
    # Find who invited this member and update their leave count
    for user_id, user_data in invites_db.get(g, {}).items():
        if isinstance(user_data, dict) and 'left' in user_data:
            # This is simplified - in a real bot you'd track who invited whom
            pass
    
    save_json(INVITE_ANALYTICS_FILE, invite_analytics_db)
    
    try:
        # Log the leave
        channel = bot.get_channel(1406419665231675432)
        if channel and isinstance(channel, discord.TextChannel):
            total_members = guild.member_count
            await channel.send(f'📊 {member.mention} has left ♡ ・TRUSTED STORE𓂃ꔫ\nTotal Members: {total_members}')
    except Exception:
        pass

@bot.event
async def on_member_join(member):
    guild = member.guild
    print(f"🔥 Member joined: {member.name} ({member.id}) in {guild.name}")
    
    try:
        invites_before = guild_invite_cache.get(guild.id, {})
        print(f"📋 Invites before: {len(invites_before)} cached invites")
        
        invites_after_list = await guild.invites()
        invites_after = {inv.code: inv.uses for inv in invites_after_list}
        guild_invite_cache[guild.id] = invites_after
        print(f"📋 Invites after: {len(invites_after)} current invites")

        inviter = None
        used_invite_code = None
        for inv in invites_after_list:
            before_uses = invites_before.get(inv.code, 0)
            print(f"🔍 Checking invite {inv.code}: before={before_uses}, after={inv.uses}")
            if inv.uses > before_uses:
                inviter = inv.inviter
                used_invite_code = inv.code
                print(f"✅ Found inviter: {inviter.name if inviter else 'Unknown'} used invite {inv.code}")
                break
                
        if inviter:
            g = str(guild.id)
            u = str(inviter.id)
            invites_db.setdefault(g, {})
            
            # Handle both old format (int) and new format (dict)
            if u not in invites_db[g] or isinstance(invites_db[g][u], int):
                old_count = invites_db[g].get(u, 0) if isinstance(invites_db[g].get(u, 0), int) else 0
                invites_db[g][u] = {'regular': old_count, 'bonus': 0, 'fake': 0, 'left': 0}
            
            # Check if this is a potential fake invite (account age < 7 days)
            account_age = (datetime.utcnow() - member.created_at).days
            if account_age < 7:
                invites_db[g][u]['fake'] += 1
                invite_type = 'fake'
                print(f"⚠️ Detected fake invite: account age {account_age} days")
            else:
                invites_db[g][u]['regular'] += 1
                invite_type = 'regular'
                print(f"✅ Regular invite: account age {account_age} days")
                
            # Update analytics
            invite_analytics_db.setdefault(g, {'total_joins': 0, 'total_leaves': 0, 'fake_detected': 0})
            invite_analytics_db[g]['total_joins'] += 1
            if invite_type == 'fake':
                invite_analytics_db[g]['fake_detected'] += 1
                
            save_json(INVITES_FILE, invites_db)
            save_json(INVITE_ANALYTICS_FILE, invite_analytics_db)
            print(f"💾 Saved invite data for {inviter.name}")
            
            # Check for invite rewards
            await check_invite_rewards(guild, inviter, invites_db[g][u])
            
            try:
                # Send to specific channel
                channel_id = 1406419665231675432
                channel = bot.get_channel(channel_id)
                print(f"📢 Looking for channel {channel_id}, found: {channel}")
                
                if channel and isinstance(channel, discord.TextChannel):
                    total_members = guild.member_count
                    total_invites = invites_db[g][u]['regular'] + invites_db[g][u]['bonus']
                    
                    if invite_type == 'fake':
                        message = f"🚨 {member.mention} has joined ♡ ・TRUSTED STORE𓂃ꔫ, invited by {inviter.mention} (FAKE INVITE - Account too new)\nInviter now has {total_invites} invites ({invites_db[g][u]['fake']} fake)\nTotal Members: {total_members}"
                    else:
                        message = f"{member.mention} has joined ♡ ・TRUSTED STORE𓂃ꔫ, invited by user {inviter.mention}, who has now {total_invites} invites.\nTotal Members: {total_members}"
                    
                    await channel.send(message)
                    print(f"✅ Sent join message to channel {channel.name}")
                else:
                    print(f"❌ Channel not found or not a text channel. Channel: {channel}")
                    # Try to find any channel in the guild to send to
                    for ch in guild.text_channels:
                        if ch.permissions_for(guild.me).send_messages:
                            await ch.send(f"DEBUG: {member.mention} joined, invited by {inviter.mention}")
                            print(f"📤 Sent debug message to {ch.name}")
                            break
                            
            except Exception as e:
                print(f"❌ Error sending join message: {e}")
                import traceback
                traceback.print_exc()
        else:
            print("❓ Could not determine inviter - sending generic join message")
            try:
                channel = bot.get_channel(1406419665231675432)
                if channel and isinstance(channel, discord.TextChannel):
                    total_members = guild.member_count
                    message = f"📊 {member.mention} has joined ♡ ・TRUSTED STORE𓂃ꔫ\nTotal Members: {total_members}"
                    await channel.send(message)
                    print("✅ Sent generic join message")
                else:
                    print("❌ Channel not found for generic message")
            except Exception as e:
                print(f"❌ Error sending generic message: {e}")
                
    except Exception as e:
        print(f"💥 Major error in invite check: {e}")
        import traceback
        traceback.print_exc()

@bot.command(name='invites')
@commands.has_guild_permissions(manage_guild=True)
async def invites_cmd(ctx, member: Optional[discord.Member] = None):
    g = str(ctx.guild.id)
    data = invites_db.get(g, {})
    if member:
        user_data = data.get(str(member.id), {'regular': 0, 'bonus': 0, 'fake': 0, 'left': 0})
        if isinstance(user_data, int):  # Handle old format
            total = user_data
        else:
            total = user_data['regular'] + user_data['bonus']
        await ctx.send(embed=make_embed(f'Invites for {member}', f'{member.mention} has {total} invites.'))
        return
    if not data:
        await ctx.send('No invites recorded yet for this server.')
        return
    # Convert and sort invite data
    processed_data = []
    for uid, user_data in data.items():
        if isinstance(user_data, int):  # Handle old format
            total = user_data
            user_data = {'regular': user_data, 'bonus': 0, 'fake': 0, 'left': 0}
        else:
            total = user_data.get('regular', 0) + user_data.get('bonus', 0)
        processed_data.append((uid, total, user_data))
    
    sorted_invites = sorted(processed_data, key=lambda x: x[1], reverse=True)
    desc = ''
    for i, (uid, total_invites, user_data) in enumerate(sorted_invites[:10], 1):
        user = ctx.guild.get_member(int(uid))
        if user:
            joins = user_data.get('regular', 0) + user_data.get('bonus', 0)
            leaves = user_data.get('left', 0)
            fakes = user_data.get('fake', 0)
            rejoins = 0  # Could be tracked separately
            
            desc += f'**#{i}** {user.mention} • **{total_invites} Invites** ({joins} Joins, {leaves} Leaves, {fakes} Fakes, {rejoins} Rejoins)\n'
        else:
            desc += f'**#{i}** Unknown User • **{total_invites} Invites**\n'
    embed = make_embed('🏆 Invite Leaderboard', desc)
    
    # Add analytics footer
    analytics = invite_analytics_db.get(g, {})
    total_joins = analytics.get('total_joins', 0)
    total_leaves = analytics.get('total_leaves', 0)
    fake_detected = analytics.get('fake_detected', 0)
    
    embed.add_field(
        name='📊 Server Analytics',
        value=f'Total Joins: {total_joins}\nTotal Leaves: {total_leaves}\nFake Invites Detected: {fake_detected}',
        inline=False
    )
    
    embed.add_field(
        name='📊 Server Statistics',
        value=f'Page 1/1 | Create live leaderboards using {bot.user.name} Premium',
        inline=False
    )
    
    await ctx.send(embed=embed)

# ─── Giveaway UI ─────────────────────────────────────────────────────────────

class LeaveConfirmView(discord.ui.View):
    def __init__(self, msg_id: int, guild_id: int):
        super().__init__(timeout=30)
        self.msg_id = msg_id
        self.guild_id = guild_id

    @discord.ui.button(label='Yes, leave', style=discord.ButtonStyle.danger, emoji='🚪')
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        g = str(self.guild_id)
        uid = interaction.user.id
        data = active_giveaways.get(g, {}).get(str(self.msg_id))
        if not data:
            await interaction.response.edit_message(content='That giveaway no longer exists.', view=None)
            self.stop()
            return
        participants = data.get('participants', [])
        if uid in participants:
            participants.remove(uid)
            data['participants'] = participants
            save_json(GIVEAWAYS_FILE, active_giveaways)
            try:
                dm = make_embed('Left Giveaway',
                    f'You have left the **{data["prize"]}** giveaway in **{interaction.guild.name}**.',
                    color=0x888888)
                await interaction.user.send(embed=dm)
            except discord.Forbidden:
                pass
            count = len(participants)
            await interaction.response.edit_message(
                content=f'✅ You left the giveaway. ({count} participant{"s" if count != 1 else ""} remaining)',
                view=None
            )
        else:
            await interaction.response.edit_message(content='You are not in this giveaway.', view=None)
        self.stop()

    @discord.ui.button(label='Cancel', style=discord.ButtonStyle.success, emoji='✖️')
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(content='✅ Cancelled — you are still in the giveaway!', view=None)
        self.stop()


class GiveawayJoinButton(discord.ui.Button):
    def __init__(self, msg_id: int, guild_id: int):
        super().__init__(
            label='Join Giveaway',
            style=discord.ButtonStyle.success,
            emoji='🎉',
            custom_id=f'gwa_join_{msg_id}'
        )
        self.msg_id = msg_id
        self.guild_id = guild_id

    async def callback(self, interaction: discord.Interaction):
        if not interaction.guild:
            await interaction.response.send_message('Error.', ephemeral=True)
            return
        g = str(self.guild_id)
        uid = interaction.user.id
        data = active_giveaways.get(g, {}).get(str(self.msg_id))
        if not data:
            await interaction.response.send_message('This giveaway has already ended.', ephemeral=True)
            return
        required_role_id = data.get('required_role_id')
        if required_role_id:
            member_role_ids = [r.id for r in interaction.user.roles]
            if required_role_id not in member_role_ids:
                role = interaction.guild.get_role(required_role_id)
                role_name = role.name if role else f'ID {required_role_id}'
                await interaction.response.send_message(
                    f'❌ {interaction.user.mention} — you need the **{role_name}** role to join this giveaway!',
                    delete_after=8
                )
                return
        participants = data.setdefault('participants', [])
        if uid in participants:
            await interaction.response.send_message('You have already entered this giveaway!', ephemeral=True)
            return
        participants.append(uid)
        save_json(GIVEAWAYS_FILE, active_giveaways)
        count = len(participants)
        try:
            dm = make_embed('🎉 Joined Giveaway!',
                f'You joined the **{data["prize"]}** giveaway in **{interaction.guild.name}**!\n'
                f'Good luck! 🍀\n\n**Participants so far:** {count}',
                color=0x00c851)
            if interaction.guild.icon:
                dm.set_thumbnail(url=interaction.guild.icon.url)
            await interaction.user.send(embed=dm)
        except discord.Forbidden:
            pass
        await interaction.response.send_message(
            f'🎉 {interaction.user.mention} joined the giveaway! ({count} participant{"s" if count != 1 else ""})',
            delete_after=8
        )


class GiveawayLeaveButton(discord.ui.Button):
    def __init__(self, msg_id: int, guild_id: int):
        super().__init__(
            label='Leave Giveaway',
            style=discord.ButtonStyle.secondary,
            emoji='🚪',
            custom_id=f'gwa_leave_{msg_id}'
        )
        self.msg_id = msg_id
        self.guild_id = guild_id

    async def callback(self, interaction: discord.Interaction):
        if not interaction.guild:
            await interaction.response.send_message('Error.', ephemeral=True)
            return
        g = str(self.guild_id)
        uid = interaction.user.id
        data = active_giveaways.get(g, {}).get(str(self.msg_id))
        if not data:
            await interaction.response.send_message('This giveaway has already ended.', ephemeral=True)
            return
        if uid not in data.get('participants', []):
            await interaction.response.send_message('You are not in this giveaway.', ephemeral=True)
            return
        confirm_view = LeaveConfirmView(self.msg_id, self.guild_id)
        await interaction.response.send_message(
            '❓ Are you sure you want to leave the giveaway?',
            view=confirm_view,
            ephemeral=True
        )


def make_giveaway_view(msg_id: int, guild_id: int) -> discord.ui.View:
    view = discord.ui.View(timeout=None)
    view.add_item(GiveawayJoinButton(msg_id, guild_id))
    view.add_item(GiveawayLeaveButton(msg_id, guild_id))
    return view


# Advanced Giveaway Features
@bot.command(name='advgiveaway')
@commands.has_permissions(manage_guild=True)
async def advanced_giveaway(ctx, minutes: int, winners: int, prize: str, role: Optional[discord.Role] = None, *, requirements: str = None):
    """Start an advanced giveaway with requirements and optional required role"""
    if minutes <= 0 or winners <= 0:
        await ctx.send('Invalid parameters.')
        return

    end_time = datetime.utcnow() + timedelta(minutes=minutes)
    desc = (
        f'🎁 **Prize:** {prize}\n'
        f'👤 **Hosted by:** {ctx.author.mention}\n'
        f'⏰ **Ends:** {end_time.strftime("%b %d at %H:%M UTC")}\n'
        f'🏆 **Winners:** {winners}\n'
    )
    if role:
        desc += f'🔒 **Required Role:** {role.mention}\n'
    if requirements:
        desc += f'📋 **Requirements:** {requirements}\n'
    desc += '\n**Press 🎉 Join Giveaway to enter!**'

    embed = make_embed('🎉 Advanced Giveaway Started! 🎉', desc)
    embed.set_footer(text=f'Winners: {winners} • Ends {end_time.strftime("%b %d at %H:%M UTC")}\nMade by Tanish14')
    if ctx.guild.icon:
        embed.set_thumbnail(url=ctx.guild.icon.url)

    g = str(ctx.guild.id)
    active_giveaways.setdefault(g, {})
    msg = await ctx.send(embed=embed)

    view = make_giveaway_view(msg.id, ctx.guild.id)
    await msg.edit(view=view)

    active_giveaways[g][str(msg.id)] = {
        'prize': prize,
        'host': ctx.author.id,
        'end_time': end_time.isoformat(),
        'winners': winners,
        'requirements': requirements or '',
        'required_role_id': role.id if role else None,
        'channel_id': ctx.channel.id,
        'participants': []
    }
    save_json(GIVEAWAYS_FILE, active_giveaways)

    await ctx.send(f'🎉 A new giveaway for **{prize}** has started! Click the button above to enter!', delete_after=12)
    asyncio.create_task(_delayed_finish_giveaway(ctx.channel, msg.id, minutes, prize, winners, ctx.guild.id))

# Anti-Nuke Protection
@bot.command(name='antinuke')
@commands.has_permissions(administrator=True)
async def antinuke_toggle(ctx, action: str = None):
    """Configure anti-nuke protection"""
    g = str(ctx.guild.id)
    antinuke_db.setdefault(g, {
        'enabled': False,
        'whitelist': [],
        'max_deletions': 5,
        'max_bans': 3,
        'max_kicks': 5,
        'max_channel_creates': 3,
        'max_role_creates': 3
    })
    
    if action == 'enable':
        antinuke_db[g]['enabled'] = True
        save_json(ANTINUKE_FILE, antinuke_db)
        await ctx.send(embed=make_embed('🛡️ Anti-Nuke Enabled', 'Anti-nuke protection is now active!'))
    elif action == 'disable':
        antinuke_db[g]['enabled'] = False
        save_json(ANTINUKE_FILE, antinuke_db)
        await ctx.send(embed=make_embed('🛡️ Anti-Nuke Disabled', 'Anti-nuke protection is now disabled.'))
    else:
        status = 'Enabled' if antinuke_db[g]['enabled'] else 'Disabled'
        embed = make_embed('🛡️ Anti-Nuke Settings', f'Status: **{status}**')
        embed.add_field(name='Settings', value=(
            f"Max Deletions: {antinuke_db[g]['max_deletions']}\n"
            f"Max Bans: {antinuke_db[g]['max_bans']}\n"
            f"Max Kicks: {antinuke_db[g]['max_kicks']}\n"
            f"Max Channel Creates: {antinuke_db[g]['max_channel_creates']}\n"
            f"Max Role Creates: {antinuke_db[g]['max_role_creates']}"
        ))
        await ctx.send(embed=embed)

@bot.command(name='antinukewhitelist')
@commands.has_permissions(administrator=True)
async def antinuke_whitelist(ctx, action: str, member: discord.Member = None):
    """Manage anti-nuke whitelist"""
    g = str(ctx.guild.id)
    antinuke_db.setdefault(g, {'enabled': False, 'whitelist': []})
    
    if action == 'add' and member:
        if member.id not in antinuke_db[g]['whitelist']:
            antinuke_db[g]['whitelist'].append(member.id)
            save_json(ANTINUKE_FILE, antinuke_db)
            await ctx.send(embed=make_embed('✅ Whitelist Updated', f'{member.mention} added to anti-nuke whitelist'))
        else:
            await ctx.send(f'{member.mention} is already whitelisted.')
    elif action == 'remove' and member:
        if member.id in antinuke_db[g]['whitelist']:
            antinuke_db[g]['whitelist'].remove(member.id)
            save_json(ANTINUKE_FILE, antinuke_db)
            await ctx.send(embed=make_embed('✅ Whitelist Updated', f'{member.mention} removed from anti-nuke whitelist'))
        else:
            await ctx.send(f'{member.mention} is not whitelisted.')
    elif action == 'list':
        whitelist = antinuke_db[g]['whitelist']
        if whitelist:
            desc = '\n'.join([f'<@{uid}>' for uid in whitelist])
            await ctx.send(embed=make_embed('🛡️ Anti-Nuke Whitelist', desc))
        else:
            await ctx.send('No users are whitelisted.')

@bot.command(name='addinvites')
@commands.has_guild_permissions(administrator=True)
async def add_invites(ctx, member: discord.Member, amount: int):
    """Add bonus invites to a member"""
    g = str(ctx.guild.id)
    u = str(member.id)
    invites_db.setdefault(g, {})
    invites_db[g].setdefault(u, {'regular': 0, 'bonus': 0, 'fake': 0, 'left': 0})
    invites_db[g][u]['bonus'] += amount
    save_json(INVITES_FILE, invites_db)
    
    total = invites_db[g][u]['regular'] + invites_db[g][u]['bonus']
    await ctx.send(embed=make_embed('Bonus Invites Added', f'Added {amount} bonus invites to {member.mention}\nThey now have {total} total invites'))

@bot.command(name='removeinvites')
@commands.has_guild_permissions(administrator=True)
async def remove_invites(ctx, member: discord.Member, amount: int):
    """Remove invites from a member"""
    g = str(ctx.guild.id)
    u = str(member.id)
    data = invites_db.get(g, {}).get(u, {'regular': 0, 'bonus': 0, 'fake': 0, 'left': 0})
    
    # Remove from bonus first, then regular
    if data['bonus'] >= amount:
        data['bonus'] -= amount
    else:
        remaining = amount - data['bonus']
        data['bonus'] = 0
        data['regular'] = max(0, data['regular'] - remaining)
    
    invites_db[g][u] = data
    save_json(INVITES_FILE, invites_db)
    
    total = data['regular'] + data['bonus']
    await ctx.send(embed=make_embed('Invites Removed', f'Removed {amount} invites from {member.mention}\nThey now have {total} total invites'))

@bot.command(name='invitereward')
@commands.has_guild_permissions(administrator=True)
async def invite_reward(ctx, milestone: int, role: discord.Role):
    """Set a role reward for reaching invite milestones"""
    g = str(ctx.guild.id)
    invite_rewards_db.setdefault(g, {})
    invite_rewards_db[g][str(milestone)] = role.id
    save_json(INVITE_REWARDS_FILE, invite_rewards_db)
    
    await ctx.send(embed=make_embed('Invite Reward Set', f'Members who reach {milestone} invites will receive the {role.mention} role'))

@bot.command(name='inviterewards')
async def invite_rewards_list(ctx):
    """List all invite milestone rewards"""
    g = str(ctx.guild.id)
    rewards = invite_rewards_db.get(g, {})
    
    if not rewards:
        await ctx.send('No invite rewards have been set for this server.')
        return
    
    desc = ''
    for milestone, role_id in sorted(rewards.items(), key=lambda x: int(x[0])):
        role = ctx.guild.get_role(int(role_id))
        role_name = role.mention if role else f'Unknown Role ({role_id})'
        desc += f'**{milestone} invites** → {role_name}\n'
    
    await ctx.send(embed=make_embed('🎁 Invite Rewards', desc))

@bot.command(name='inviteinfo')
async def invite_info(ctx, member: discord.Member = None):
    """Show detailed invite information for a member"""
    if not member:
        member = ctx.author
        
    g = str(ctx.guild.id)
    data = invites_db.get(g, {}).get(str(member.id), {'regular': 0, 'bonus': 0, 'fake': 0, 'left': 0})
    
    total = data['regular'] + data['bonus']
    embed = make_embed(f'📊 Invite Stats for {member.display_name}', '')
    embed.add_field(name='Total Invites', value=str(total), inline=True)
    embed.add_field(name='Regular Invites', value=str(data['regular']), inline=True)
    embed.add_field(name='Bonus Invites', value=str(data['bonus']), inline=True)
    embed.add_field(name='Fake Invites', value=str(data['fake']), inline=True)
    embed.add_field(name='Left Members', value=str(data['left']), inline=True)
    embed.add_field(name='Success Rate', value=f"{((data['regular'] / max(1, data['regular'] + data['fake'])) * 100):.1f}%", inline=True)
    
    await ctx.send(embed=embed)

@bot.command(name='resetleaderboard')
@commands.has_guild_permissions(administrator=True)
async def reset_leaderboard(ctx):
    g = str(ctx.guild.id)
    invites_db[g] = {}
    save_json(INVITES_FILE, invites_db)
    await ctx.send(embed=make_embed('Reset', 'Invite leaderboard has been reset by an administrator.'))

@bot.command(name='addresponder')
@commands.has_guild_permissions(manage_messages=True)
async def add_responder(ctx, trigger: str, *, response: str):
    g = str(ctx.guild.id)
    autorespond_db.setdefault(g, [])
    autorespond_db[g].append({'trigger': trigger.lower(), 'response': response})
    save_json(AUTORESPOND_FILE, autorespond_db)
    await ctx.send(embed=make_embed('Added Responder', f'When a message contains `{trigger}` I will reply with the given response.'))

@bot.command(name='listresponders')
@commands.has_guild_permissions(manage_messages=True)
async def list_responders(ctx):
    g = str(ctx.guild.id)
    items = autorespond_db.get(g, [])
    if not items:
        await ctx.send('No autoresponders set for this server.')
        return
    desc = '\n'.join([f"**{i+1}.** `{it['trigger']}` -> {it['response']}" for i, it in enumerate(items)])
    await ctx.send(embed=make_embed('Autoresponders', desc))

@bot.command(name='removeresponder')
@commands.has_guild_permissions(manage_messages=True)
async def remove_responder(ctx, index: int):
    g = str(ctx.guild.id)
    items = autorespond_db.get(g, [])
    if not items or index <= 0 or index > len(items):
        await ctx.send('Invalid index')
        return
    removed = items.pop(index-1)
    save_json(AUTORESPOND_FILE, autorespond_db)
    await ctx.send(embed=make_embed('Removed', f'Removed responder: `{removed["trigger"]}`'))

# ─── Spam tracker (in-memory) ─────────────────────────────────────────────────
# Maps (guild_id, user_id) → list of message timestamps
spam_tracker: dict[tuple, list] = {}

DEFAULT_AUTOMOD = {
    'enabled': True,
    'link_filter': True,
    'spam_filter': True,
    'mention_filter': True,
    'badword_filter': True,
    'badwords': ['fuck', 'shit', 'bitch', 'nigga', 'nigger', 'asshole', 'bastard'],
    'timeout_minutes': 60,
    'spam_threshold': 5,
    'spam_window': 5,
    'mention_threshold': 3,
}

async def automod_punish(message: discord.Message, violation: str, detail: str = ''):
    """Delete message, apply 1-hr timeout + mute role + 1 warning, send temp msg, DM, log."""
    guild = message.guild
    member = message.author

    try:
        await message.delete()
    except Exception:
        pass

    until = discord.utils.utcnow() + timedelta(hours=1)
    try:
        await member.edit(timed_out_until=until, reason=f'AutoMod: {violation}')
    except Exception:
        pass

    mute_role = guild.get_role(1409565499083329567) or discord.utils.get(guild.roles, name='Muted')
    if mute_role:
        try:
            await member.add_roles(mute_role, reason=f'AutoMod: {violation}')
            asyncio.create_task(_automod_unmute(member.id, guild.id, 60))
        except Exception:
            pass

    g = str(guild.id)
    warns_db.setdefault(g, {})
    warns_db[g].setdefault(str(member.id), [])
    warns_db[g][str(member.id)].append({
        'by': bot.user.id,
        'reason': f'[AutoMod] {violation}',
        'time': datetime.utcnow().isoformat()
    })
    save_json(WARNS_FILE, warns_db)
    warn_count = len(warns_db[g][str(member.id)])

    label_map = {
        'link': '🔗 No links allowed',
        'spam': '⚡ No spamming',
        'mention': '📢 No mention spam',
        'badword': '🤬 No bad words',
    }
    violation_label = label_map.get(violation, f'🚫 {violation}')

    temp_embed = make_embed(
        f'{violation_label}',
        f'{member.mention} has been **timed out for 1 hour** and received **Warning #{warn_count}**.\n'
        f'{"**Detail:** " + detail + chr(10) if detail else ""}'
        f'This behaviour is not allowed in this server.',
        color=0xff4444
    )
    try:
        await message.channel.send(embed=temp_embed, delete_after=12)
    except Exception:
        pass

    try:
        dm = make_embed(
            f'⚠️ AutoMod: {violation_label}',
            f'You were automatically punished in **{guild.name}**.\n\n'
            f'**Reason:** {violation_label}\n'
            f'**Punishment:** 1-hour timeout + Mute role + Warning #{warn_count}\n\n'
            f'This behaviour is **not allowed** in this server. Please read the rules.',
            color=0xff4444
        )
        await member.send(embed=dm)
    except discord.Forbidden:
        pass

    try:
        log_channel = bot.get_channel(LOG_CHANNEL_ID)
        if log_channel and isinstance(log_channel, discord.TextChannel):
            log_embed = make_embed(
                f'🤖 AutoMod — {violation_label}',
                f'**Member:** {member.mention}\n'
                f'**Violation:** {violation_label}\n'
                f'**Warning #:** {warn_count}\n'
                f'**Timeout:** 1 hour\n'
                f'**Channel:** {message.channel.mention}',
                color=0xff4444
            )
            await log_channel.send(embed=log_embed)
    except Exception:
        pass


async def _automod_unmute(member_id: int, guild_id: int, minutes: int):
    await asyncio.sleep(minutes * 60)
    guild = bot.get_guild(guild_id)
    if not guild:
        return
    member = guild.get_member(member_id)
    if not member:
        return
    role = guild.get_role(1409565499083329567) or discord.utils.get(guild.roles, name='Muted')
    if role and role in member.roles:
        try:
            await member.remove_roles(role, reason='AutoMod: auto unmute after timeout')
        except Exception:
            pass


def get_automod_cfg(guild_id: str) -> dict:
    cfg = automod_db.get(guild_id, {})
    merged = {**DEFAULT_AUTOMOD, **cfg}
    if 'badwords' not in cfg:
        merged['badwords'] = DEFAULT_AUTOMOD['badwords']
    return merged


@bot.event
async def on_message(message):
    if message.author.bot:
        return
    if not message.guild:
        await bot.process_commands(message)
        return

    member = message.author
    g = str(message.guild.id)

    # Moderators are immune to automod
    is_mod = (
        member.guild_permissions.manage_messages or
        member.guild_permissions.moderate_members or
        member.guild_permissions.administrator
    )

    if not is_mod:
        cfg = get_automod_cfg(g)
        if cfg.get('enabled', True):
            content = message.content
            content_lower = content.lower()

            # 1. Link filter
            if cfg.get('link_filter', True):
                url_pattern = r'https?://[\S]+|www\.[\S]+'
                if re.search(url_pattern, content, re.IGNORECASE):
                    await automod_punish(message, 'link', 'No links allowed in this server.')
                    return

            # 2. Spam filter
            if cfg.get('spam_filter', True):
                threshold = cfg.get('spam_threshold', 5)
                window = cfg.get('spam_window', 5)
                key = (message.guild.id, member.id)
                now = datetime.utcnow()
                spam_tracker.setdefault(key, [])
                spam_tracker[key].append(now)
                spam_tracker[key] = [t for t in spam_tracker[key] if (now - t).total_seconds() <= window]
                if len(spam_tracker[key]) >= threshold:
                    spam_tracker[key] = []
                    await automod_punish(message, 'spam', f'Sending too many messages too quickly ({threshold}+ in {window}s).')
                    return

            # 3. Mention spam filter
            if cfg.get('mention_filter', True):
                mention_count = len(message.mentions) + len(message.role_mentions)
                threshold = cfg.get('mention_threshold', 3)
                if mention_count >= threshold:
                    await automod_punish(message, 'mention', f'Too many mentions in one message ({mention_count}).')
                    return

            # 4. Bad word filter
            if cfg.get('badword_filter', True):
                badwords = cfg.get('badwords', [])
                found = next((w for w in badwords if w.lower() in content_lower), None)
                if found:
                    await automod_punish(message, 'badword', f'Prohibited language detected.')
                    return

    # Autoresponder
    items = autorespond_db.get(g, [])
    content_lower = message.content.lower()
    for it in items:
        if it['trigger'] in content_lower:
            try:
                await message.channel.send(it['response'])
            except Exception:
                pass
    await bot.process_commands(message)

LOG_CHANNEL_ID = 1407004168580894874

WARN_THRESHOLDS = {
    3: 'mute',
    5: 'kick',
    7: 'ban',
}

def format_warn_time(iso_str: str) -> str:
    try:
        dt = datetime.fromisoformat(iso_str)
        return dt.strftime('%b %d, %Y at %H:%M UTC')
    except Exception:
        return iso_str

async def apply_warn_threshold(guild: discord.Guild, member: discord.Member, warn_count: int, moderator: discord.Member | discord.User):
    action = WARN_THRESHOLDS.get(warn_count)
    if not action:
        return None

    reason = f'Automatic action: reached {warn_count} warnings'

    if action == 'mute':
        until = discord.utils.utcnow() + timedelta(minutes=10)
        try:
            await member.edit(timed_out_until=until, reason=reason)
            try:
                dm = make_embed('Auto-Mute', f'You have been automatically timed out in **{guild.name}** for 10 minutes after reaching {warn_count} warnings.', color=0xff9500)
                await member.send(embed=dm)
            except discord.Forbidden:
                pass
            return f'⚠️ Auto-muted for 10 minutes (reached {warn_count} warnings)'
        except Exception:
            return None

    elif action == 'kick':
        try:
            try:
                dm = make_embed('Auto-Kick', f'You have been automatically kicked from **{guild.name}** after reaching {warn_count} warnings.', color=0xff0000)
                await member.send(embed=dm)
            except discord.Forbidden:
                pass
            await member.kick(reason=reason)
            return f'⚠️ Auto-kicked (reached {warn_count} warnings)'
        except Exception:
            return None

    elif action == 'ban':
        try:
            try:
                dm = make_embed('Auto-Ban', f'You have been automatically banned from **{guild.name}** after reaching {warn_count} warnings.', color=0xff0000)
                await member.send(embed=dm)
            except discord.Forbidden:
                pass
            await guild.ban(member, reason=reason)
            return f'⚠️ Auto-banned (reached {warn_count} warnings)'
        except Exception:
            return None

    return None

@bot.command(name='warn')
@commands.has_permissions(kick_members=True)
async def warn(ctx, member: discord.Member, *, reason: str = 'No reason provided'):
    g = str(ctx.guild.id)
    warns_db.setdefault(g, {})
    warns_db[g].setdefault(str(member.id), [])
    warns_db[g][str(member.id)].append({'by': ctx.author.id, 'reason': reason, 'time': datetime.utcnow().isoformat()})
    save_json(WARNS_FILE, warns_db)
    warn_count = len(warns_db[g][str(member.id)])

    try:
        dm = make_embed('You have been warned', f'You were warned in **{ctx.guild.name}** by {ctx.author.mention}.\n**Reason:** {reason}\n**Total warnings:** {warn_count}', color=0xff9500)
        await member.send(embed=dm)
    except discord.Forbidden:
        pass

    try:
        log_channel = bot.get_channel(LOG_CHANNEL_ID)
        if log_channel and isinstance(log_channel, discord.TextChannel):
            log_embed = make_embed('⚠️ Member Warned', f'**Member:** {member.mention}\n**Reason:** {reason}\n**Moderator:** {ctx.author.mention}\n**Total Warnings:** {warn_count}', color=0xff9500)
            await log_channel.send(embed=log_embed)
    except Exception:
        pass

    embed = make_embed('⚠️ Warned', f'{member.mention} has been warned.\n**Reason:** {reason}\n**Total warnings:** {warn_count}')
    await ctx.send(embed=embed)

    auto_msg = await apply_warn_threshold(ctx.guild, member, warn_count, ctx.author)
    if auto_msg:
        await ctx.send(embed=make_embed('Auto-Action Triggered', auto_msg, color=0xff9500))

@bot.command(name='warnings')
@commands.has_permissions(kick_members=True)
async def warnings(ctx, member: discord.Member):
    g = str(ctx.guild.id)
    user_warns = warns_db.get(g, {}).get(str(member.id), [])
    if not user_warns:
        await ctx.send(f'{member.mention} has no warnings.')
        return
    desc = ''
    for i, w in enumerate(user_warns, 1):
        by = ctx.guild.get_member(w['by'])
        by_name = by.display_name if by else str(w['by'])
        desc += f'**{i}.** By **{by_name}** on {format_warn_time(w["time"])}\n└ {w["reason"]}\n'
    embed = make_embed(f'⚠️ Warnings for {member.display_name} ({len(user_warns)} total)', desc)
    embed.set_thumbnail(url=member.display_avatar.url)
    await ctx.send(embed=embed)

@bot.command(name='clearwarnings')
@commands.has_permissions(administrator=True)
async def clear_warnings(ctx, member: discord.Member):
    g = str(ctx.guild.id)
    if g in warns_db and str(member.id) in warns_db[g]:
        warns_db[g].pop(str(member.id), None)
        save_json(WARNS_FILE, warns_db)
    await ctx.send(embed=make_embed('✅ Cleared', f'All warnings for {member.mention} have been cleared.'))

@bot.command(name='removewarn')
@commands.has_permissions(kick_members=True)
async def removewarn(ctx, member: discord.Member, index: int):
    g = str(ctx.guild.id)
    user_warns = warns_db.get(g, {}).get(str(member.id), [])
    if not user_warns:
        await ctx.send(f'{member.mention} has no warnings.')
        return
    if index < 1 or index > len(user_warns):
        await ctx.send(f'Invalid warning number. {member.mention} has {len(user_warns)} warning(s).')
        return
    removed = user_warns.pop(index - 1)
    save_json(WARNS_FILE, warns_db)
    await ctx.send(embed=make_embed('✅ Warning Removed', f'Removed warning #{index} from {member.mention}.\n**Reason was:** {removed["reason"]}'))

async def get_muted_role(guild: discord.Guild):
    # Use the specific role ID provided
    role = guild.get_role(1409565499083329567)
    if not role:
        # Fallback: try to find role by name if ID doesn't exist
        role = discord.utils.get(guild.roles, name='Muted')
        if not role:
            # Last resort: create the role
            perms = discord.Permissions.none()
            role = await guild.create_role(name='Muted', permissions=perms, reason='Create muted role for moderation')
            for ch in guild.channels:
                try:
                    await ch.set_permissions(role, send_messages=False, speak=False, add_reactions=False)
                except Exception:
                    pass
    return role

# Advanced invite functions
async def check_invite_rewards(guild: discord.Guild, inviter: discord.Member, invite_data: dict):
    """Check and apply invite milestone rewards"""
    g = str(guild.id)
    rewards = invite_rewards_db.get(g, {})
    total_invites = invite_data['regular'] + invite_data['bonus']
    
    for milestone, role_id in rewards.items():
        if total_invites >= int(milestone):
            role = guild.get_role(int(role_id))
            if role and role not in inviter.roles:
                try:
                    await inviter.add_roles(role, reason=f'Invite milestone: {milestone} invites')
                    # Notify in invite channel
                    channel = bot.get_channel(1406419665231675432)
                    if channel and isinstance(channel, discord.TextChannel):
                        await channel.send(f'🎉 {inviter.mention} reached {milestone} invites and earned the {role.mention} role!')
                except Exception:
                    pass

async def _auto_unmute(member_id: int, guild_id: int, minutes: int):
    await asyncio.sleep(minutes * 60)
    guild = bot.get_guild(guild_id)
    if not guild:
        return
    member = guild.get_member(member_id)
    if not member:
        return
    # Use the specific role ID
    role = guild.get_role(1409565499083329567)
    if not role:
        role = discord.utils.get(guild.roles, name='Muted')
    if role and role in member.roles:
        try:
            await member.remove_roles(role, reason='Auto unmute')
        except Exception:
            pass

@bot.command(name='mute')
@commands.has_permissions(manage_roles=True)
async def mute(ctx, member: discord.Member, minutes: Optional[int] = None):
    role = await get_muted_role(ctx.guild)
    try:
        author_name = ctx.author.display_name if ctx.author else "Unknown"
        await member.add_roles(role, reason=f'Muted by {author_name}')
    except Exception:
        await ctx.send('Failed to add mute role.')
        return
    
    # Send DM to the user
    try:
        if minutes:
            dm_embed = make_embed('You have been muted', f'You have been muted in **{ctx.guild.name}** for **{minutes} minutes** by {ctx.author.mention}.', color=0xff9500)
        else:
            dm_embed = make_embed('You have been muted', f'You have been muted in **{ctx.guild.name}** indefinitely by {ctx.author.mention}.', color=0xff9500)
        await member.send(embed=dm_embed)
    except discord.Forbidden:
        pass  # User has DMs disabled
    
    if minutes:
        asyncio.create_task(_auto_unmute(member.id, ctx.guild.id, minutes))
        await ctx.send(embed=make_embed('Muted', f'{member.mention} has been muted for {minutes} minutes.'))
    else:
        await ctx.send(embed=make_embed('Muted', f'{member.mention} has been muted indefinitely.'))

@bot.command(name='unmute')
@commands.has_permissions(manage_roles=True)
async def unmute(ctx, member: discord.Member):
    # Use the specific role ID
    role = ctx.guild.get_role(1409565499083329567)
    if not role:
        role = discord.utils.get(ctx.guild.roles, name='Muted')
    if role and role in member.roles:
        await member.remove_roles(role, reason=f'Unmuted by {ctx.author}')
        await ctx.send(embed=make_embed('Unmuted', f'{member.mention} has been unmuted.'))
    else:
        await ctx.send('That user is not muted.')

@bot.tree.command(name="mute", description="Mute a member")
@app_commands.describe(member="Member to mute", minutes="Minutes to mute them for")
async def mute_slash(interaction: discord.Interaction, member: discord.Member, minutes: Optional[int] = None):
    if not interaction.guild:
        await interaction.response.send_message("This command can only be used in a server.")
        return
    
    role = await get_muted_role(interaction.guild)
    user_name = interaction.user.display_name if interaction.user else "Unknown"
    await member.add_roles(role, reason=f'Muted by {user_name}')
    
    # Send DM to the user
    try:
        if minutes:
            dm_embed = make_embed('You have been muted', f'You have been muted in **{interaction.guild.name}** for **{minutes} minutes** by {interaction.user.mention}.', color=0xff9500)
        else:
            dm_embed = make_embed('You have been muted', f'You have been muted in **{interaction.guild.name}** indefinitely by {interaction.user.mention}.', color=0xff9500)
        await member.send(embed=dm_embed)
    except discord.Forbidden:
        pass  # User has DMs disabled
    
    if minutes:
        asyncio.create_task(_auto_unmute(member.id, interaction.guild.id, minutes))
        await interaction.response.send_message(f'{member.mention} muted for {minutes} minutes.')
    else:
        await interaction.response.send_message(f'{member.mention} muted indefinitely.')

@bot.tree.command(name="timeout", description="Timeout a member for a specified duration")
@app_commands.describe(member="Member to timeout", minutes="Minutes to timeout them for")
async def timeout_slash(interaction: discord.Interaction, member: discord.Member, minutes: int = 10):
    if not interaction.guild:
        await interaction.response.send_message("This command can only be used in a server.")
        return
    
    # Send DM to the user before timeout
    try:
        dm_embed = make_embed('You have been timed out', f'You have been timed out in **{interaction.guild.name}** for **{minutes} minutes** by {interaction.user.mention}.', color=0xff9500)
        await member.send(embed=dm_embed)
    except discord.Forbidden:
        pass
    
    until = discord.utils.utcnow() + timedelta(minutes=minutes)
    try:
        await member.edit(timed_out_until=until, reason=f'Timed out by {interaction.user.display_name}')
        await interaction.response.send_message(f'{member.mention} has been timed out for {minutes} minutes.')
    except discord.HTTPException as e:
        await interaction.response.send_message(f'Timeout failed: {e}. Make sure the bot has "Timeout Members" permission.')
    except Exception as e:
        await interaction.response.send_message(f'Timeout failed: {e}')

@bot.tree.command(name="kick", description="Kick a member from the server")
@app_commands.describe(member="Member to kick", reason="Reason for kicking")
async def kick_slash(interaction: discord.Interaction, member: discord.Member, reason: Optional[str] = None):
    if not interaction.guild:
        await interaction.response.send_message("This command can only be used in a server.")
        return
    
    # Send DM to the user before kicking
    try:
        reason_text = reason or "No reason provided"
        dm_embed = make_embed('You have been kicked', f'You have been kicked from **{interaction.guild.name}** by {interaction.user.mention}.\nReason: {reason_text}', color=0xff0000)
        await member.send(embed=dm_embed)
    except discord.Forbidden:
        pass
    
    try:
        await member.kick(reason=reason)
        await interaction.response.send_message(f'{member.mention} has been kicked. Reason: {reason or "No reason provided"}')
    except Exception as e:
        await interaction.response.send_message(f'Failed to kick: {e}')

@bot.tree.command(name="ban", description="Ban a member from the server")
@app_commands.describe(member="Member to ban", days="Days of messages to delete", reason="Reason for banning")
async def ban_slash(interaction: discord.Interaction, member: discord.Member, days: int = 0, reason: Optional[str] = None):
    if not interaction.guild:
        await interaction.response.send_message("This command can only be used in a server.")
        return
    
    # Send DM to the user before banning
    try:
        reason_text = reason or "No reason provided"
        dm_embed = make_embed('You have been banned', f'You have been banned from **{interaction.guild.name}** by {interaction.user.mention}.\nReason: {reason_text}', color=0xff0000)
        await member.send(embed=dm_embed)
    except discord.Forbidden:
        pass
    
    try:
        await interaction.guild.ban(member, reason=reason, delete_message_days=days)
        await interaction.response.send_message(f'{member.mention} has been banned. Reason: {reason or "No reason provided"}')
    except Exception as e:
        await interaction.response.send_message(f'Failed to ban: {e}')

@bot.tree.command(name="warn", description="Warn a member")
@app_commands.describe(member="Member to warn", reason="Reason for warning")
async def warn_slash(interaction: discord.Interaction, member: discord.Member, reason: Optional[str] = None):
    if not interaction.guild:
        await interaction.response.send_message("This command can only be used in a server.")
        return

    if not interaction.user.guild_permissions.kick_members:
        await interaction.response.send_message("❌ You need kick members permission to warn users.", ephemeral=True)
        return

    reason = reason or 'No reason provided'
    g = str(interaction.guild.id)
    warns_db.setdefault(g, {})
    warns_db[g].setdefault(str(member.id), [])
    warns_db[g][str(member.id)].append({'by': interaction.user.id, 'reason': reason, 'time': datetime.utcnow().isoformat()})
    save_json(WARNS_FILE, warns_db)
    warn_count = len(warns_db[g][str(member.id)])

    try:
        dm = make_embed('You have been warned', f'You were warned in **{interaction.guild.name}** by {interaction.user.mention}.\n**Reason:** {reason}\n**Total warnings:** {warn_count}', color=0xff9500)
        await member.send(embed=dm)
    except discord.Forbidden:
        pass

    try:
        log_channel = bot.get_channel(LOG_CHANNEL_ID)
        if log_channel and isinstance(log_channel, discord.TextChannel):
            log_embed = make_embed('⚠️ Member Warned', f'**Member:** {member.mention}\n**Reason:** {reason}\n**Moderator:** {interaction.user.mention}\n**Total Warnings:** {warn_count}', color=0xff9500)
            await log_channel.send(embed=log_embed)
    except Exception:
        pass

    embed = make_embed('⚠️ Warned', f'{member.mention} has been warned.\n**Reason:** {reason}\n**Total warnings:** {warn_count}')
    await interaction.response.send_message(embed=embed)

    auto_msg = await apply_warn_threshold(interaction.guild, member, warn_count, interaction.user)
    if auto_msg:
        await interaction.followup.send(embed=make_embed('Auto-Action Triggered', auto_msg, color=0xff9500))

@bot.tree.command(name="warnings", description="View warnings for a member")
@app_commands.describe(member="Member to check warnings for")
async def warnings_slash(interaction: discord.Interaction, member: discord.Member):
    if not interaction.guild:
        await interaction.response.send_message("This command can only be used in a server.")
        return

    g = str(interaction.guild.id)
    user_warns = warns_db.get(g, {}).get(str(member.id), [])
    if not user_warns:
        await interaction.response.send_message(f'{member.mention} has no warnings.')
        return
    desc = ''
    for i, w in enumerate(user_warns, 1):
        by = interaction.guild.get_member(w['by'])
        by_name = by.display_name if by else str(w['by'])
        desc += f'**{i}.** By **{by_name}** on {format_warn_time(w["time"])}\n└ {w["reason"]}\n'
    embed = make_embed(f'⚠️ Warnings for {member.display_name} ({len(user_warns)} total)', desc)
    embed.set_thumbnail(url=member.display_avatar.url)
    await interaction.response.send_message(embed=embed)

@bot.tree.command(name="clearwarnings", description="Clear all warnings for a member (Admin only)")
@app_commands.describe(member="Member to clear warnings for")
async def clearwarnings_slash(interaction: discord.Interaction, member: discord.Member):
    if not interaction.guild:
        await interaction.response.send_message("This command can only be used in a server.")
        return

    if not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message("❌ You need administrator permissions to clear warnings.", ephemeral=True)
        return

    g = str(interaction.guild.id)
    if g in warns_db and str(member.id) in warns_db[g]:
        warns_db[g].pop(str(member.id), None)
        save_json(WARNS_FILE, warns_db)
    await interaction.response.send_message(embed=make_embed('✅ Cleared', f'All warnings for {member.mention} have been cleared.'))

@bot.tree.command(name="removewarn", description="Remove a specific warning from a member")
@app_commands.describe(member="Member to remove a warning from", index="Warning number to remove (use /warnings to see numbers)")
async def removewarn_slash(interaction: discord.Interaction, member: discord.Member, index: int):
    if not interaction.guild:
        await interaction.response.send_message("This command can only be used in a server.")
        return

    if not interaction.user.guild_permissions.kick_members:
        await interaction.response.send_message("❌ You need kick members permission to remove warnings.", ephemeral=True)
        return

    g = str(interaction.guild.id)
    user_warns = warns_db.get(g, {}).get(str(member.id), [])
    if not user_warns:
        await interaction.response.send_message(f'{member.mention} has no warnings.')
        return
    if index < 1 or index > len(user_warns):
        await interaction.response.send_message(f'Invalid warning number. {member.mention} has {len(user_warns)} warning(s).')
        return
    removed = user_warns.pop(index - 1)
    save_json(WARNS_FILE, warns_db)
    await interaction.response.send_message(embed=make_embed('✅ Warning Removed', f'Removed warning #{index} from {member.mention}.\n**Reason was:** {removed["reason"]}'))

@bot.tree.command(name="invites", description="Check invite count for a member or show leaderboard")
@app_commands.describe(member="Member to check invites for (optional)")
async def invites_slash(interaction: discord.Interaction, member: Optional[discord.Member] = None):
    if not interaction.guild:
        await interaction.response.send_message("This command can only be used in a server.")
        return
    
    g = str(interaction.guild.id)
    data = invites_db.get(g, {})
    if member:
        count = data.get(str(member.id), 0)
        embed = make_embed(f'Invites for {member}', f'{member.mention} has {count} invites.')
        await interaction.response.send_message(embed=embed)
        return
    if not data:
        await interaction.response.send_message('No invites recorded yet for this server.')
        return
    sorted_invites = sorted(data.items(), key=lambda x: x[1], reverse=True)
    desc = ''
    for i, (uid, count) in enumerate(sorted_invites[:10], 1):
        user = interaction.guild.get_member(int(uid))
        name = user.display_name if user else f'Unknown ({uid})'
        desc += f'**{i}.** {name} — {count}\n'
    embed = make_embed('Invite Leaderboard', desc)
    await interaction.response.send_message(embed=embed)

def parse_duration(text: str) -> Optional[int]:
    """Parse a duration string like '30m', '2h', '1d', '1h30m' into total minutes."""
    text = text.strip().lower().replace(' ', '')
    total = 0
    matches = re.findall(r'(\d+)([dhm]?)', text)
    for amount, unit in matches:
        amount = int(amount)
        if unit == 'd':
            total += amount * 1440
        elif unit == 'h':
            total += amount * 60
        else:
            total += amount
    return total if total > 0 else None


class GiveawayModal(discord.ui.Modal, title='🎉 Create a Giveaway'):
    def __init__(self, required_role: Optional[discord.Role] = None):
        super().__init__()
        self.required_role = required_role

    giveaway_name = discord.ui.TextInput(
        label='Giveaway Name',
        placeholder='e.g. Weekend Special Giveaway',
        required=True,
        max_length=100
    )
    prize = discord.ui.TextInput(
        label='Prize',
        placeholder='e.g. $10 Gift Card, Discord Nitro, etc.',
        required=True,
        max_length=200
    )
    duration = discord.ui.TextInput(
        label='Duration',
        placeholder='30m  •  2h  •  1d  •  1h30m',
        required=True,
        max_length=20
    )
    winners_input = discord.ui.TextInput(
        label='Number of Winners',
        placeholder='e.g. 1',
        required=True,
        max_length=3
    )
    description = discord.ui.TextInput(
        label='Description (optional)',
        placeholder='e.g. Like our server to qualify! Open to all members.',
        required=False,
        max_length=300,
        style=discord.TextStyle.paragraph
    )

    async def on_submit(self, interaction: discord.Interaction):
        minutes = parse_duration(str(self.duration.value))
        if not minutes or minutes <= 0:
            await interaction.response.send_message(
                '❌ Invalid duration. Use formats like `30m`, `2h`, `1d`, `1h30m`.',
                ephemeral=True
            )
            return

        try:
            winners_count = int(str(self.winners_input.value).strip())
            if winners_count <= 0:
                raise ValueError
        except ValueError:
            await interaction.response.send_message(
                '❌ Winners must be a positive whole number.',
                ephemeral=True
            )
            return

        name = str(self.giveaway_name.value).strip()
        prize = str(self.prize.value).strip()
        description_text = str(self.description.value).strip()
        end_time = datetime.utcnow() + timedelta(minutes=minutes)

        giveaway_description = (
            f'🎁 **Prize:** {prize}\n'
            f'👤 **Hosted by:** {interaction.user.mention}\n'
            f'⏰ **Ends:** {end_time.strftime("%b %d at %H:%M UTC")}\n'
            f'🏆 **Winners:** {winners_count}\n'
        )
        if self.required_role:
            giveaway_description += f'🔒 **Required Role:** {self.required_role.mention}\n'
        if description_text:
            giveaway_description += f'\n📋 **Description:**\n{description_text}\n'
        giveaway_description += '\n**Press 🎉 Join Giveaway to enter!**'

        embed = make_embed(f'🎉 {name} 🎉', giveaway_description)
        embed.set_footer(text=f'Winners: {winners_count} • Ends {end_time.strftime("%b %d at %H:%M UTC")}\nMade by Tanish14')
        if interaction.guild.icon:
            embed.set_thumbnail(url=interaction.guild.icon.url)

        await interaction.response.send_message(embed=embed)
        msg = await interaction.original_response()

        g = str(interaction.guild.id)
        active_giveaways.setdefault(g, {})
        active_giveaways[g][str(msg.id)] = {
            'prize': prize,
            'name': name,
            'host': interaction.user.id,
            'end_time': end_time.isoformat(),
            'winners': winners_count,
            'description': description_text,
            'required_role_id': self.required_role.id if self.required_role else None,
            'channel_id': interaction.channel.id,
            'participants': []
        }
        save_json(GIVEAWAYS_FILE, active_giveaways)

        view = make_giveaway_view(msg.id, interaction.guild.id)
        await msg.edit(view=view)
        await interaction.followup.send(
            f'🎉 **{name}** giveaway has started! Click the button above to enter!',
            ephemeral=False
        )
        asyncio.create_task(_delayed_finish_giveaway(
            interaction.channel, msg.id, minutes, prize, winners_count, interaction.guild.id
        ))

    async def on_error(self, interaction: discord.Interaction, error: Exception):
        await interaction.response.send_message('❌ Something went wrong. Please try again.', ephemeral=True)


@bot.tree.command(name="giveaway", description="Create a new giveaway (opens setup panel)")
@app_commands.describe(required_role="Role members must have to enter this giveaway (optional)")
async def giveaway_slash(interaction: discord.Interaction, required_role: Optional[discord.Role] = None):
    if not interaction.guild:
        await interaction.response.send_message('This command can only be used in a server.')
        return
    if not interaction.user.guild_permissions.manage_guild:
        await interaction.response.send_message('❌ You need Manage Server permission to start a giveaway.', ephemeral=True)
        return
    await interaction.response.send_modal(GiveawayModal(required_role=required_role))


async def greroll_name_autocomplete(interaction: discord.Interaction, current: str) -> list[app_commands.Choice[str]]:
    if not interaction.guild:
        return []
    g = str(interaction.guild.id)
    guild_ended = ended_giveaways_db.get(g, {})
    seen = {}
    for gdata in guild_ended.values():
        gname = gdata.get('name', gdata.get('prize', ''))
        if gname and current.lower() in gname.lower():
            seen[gname] = gname
    return [app_commands.Choice(name=n, value=n) for n in list(seen.keys())[:25]]


@bot.tree.command(name="greroll", description="Reroll a winner for an ended giveaway by name")
@app_commands.describe(name="Name of the ended giveaway (as you set it when creating)")
@app_commands.autocomplete(name=greroll_name_autocomplete)
async def greroll_slash(interaction: discord.Interaction, name: str):
    if not interaction.guild:
        await interaction.response.send_message("This command can only be used in a server.")
        return

    if not interaction.user.guild_permissions.manage_guild:
        await interaction.response.send_message("❌ You need Manage Server permission to reroll.", ephemeral=True)
        return

    g = str(interaction.guild.id)
    guild_ended = ended_giveaways_db.get(g, {})

    # Find the most recent ended giveaway matching the name (case-insensitive)
    found_msg_id = None
    data = None
    for msg_id_str, gdata in guild_ended.items():
        stored_name = gdata.get('name', gdata.get('prize', ''))
        if stored_name.lower() == name.lower():
            # Pick the most recently ended one
            if found_msg_id is None or gdata.get('ended_at', '') > guild_ended[found_msg_id].get('ended_at', ''):
                found_msg_id = msg_id_str
                data = gdata

    if not data:
        await interaction.response.send_message(
            f"❌ No ended giveaway found with the name **{name}**. Make sure you use the exact giveaway name.",
            ephemeral=True
        )
        return

    message_id = found_msg_id

    participants = data.get('participants', [])
    if not participants:
        await interaction.response.send_message("❌ That giveaway had no participants to reroll from.", ephemeral=True)
        return

    new_winner_id = random.choice(participants)
    new_winner = interaction.guild.get_member(new_winner_id)
    if not new_winner:
        await interaction.response.send_message("❌ Could not resolve the new winner (they may have left the server).", ephemeral=True)
        return

    prize = data.get('prize', 'Unknown Prize')

    prev_winner_ids = data.get('current_winners', [])
    await _remove_winner_role(interaction.guild, prev_winner_ids)

    for old_uid in prev_winner_ids:
        old_member = interaction.guild.get_member(old_uid)
        if old_member:
            try:
                disq_dm = make_embed(
                    '❌ Giveaway — You Have Been Disqualified',
                    f'You have been removed as the winner of the **{prize}** giveaway in **{interaction.guild.name}**.\n\n'
                    f'**Reason:** Requirements were not fulfilled.\n\n'
                    f'Your **Giveaway Winner** role has been removed.',
                    color=0xff4444
                )
                if interaction.guild.icon:
                    disq_dm.set_thumbnail(url=interaction.guild.icon.url)
                await old_member.send(embed=disq_dm)
            except discord.Forbidden:
                pass

    await _give_winner_role(interaction.guild, [new_winner])

    ended_giveaways_db[g][message_id]['current_winners'] = [new_winner.id]
    save_json(ENDED_GIVEAWAYS_FILE, ended_giveaways_db)

    win_embed = make_embed(
        '🎉 Giveaway Reroll!',
        f'🏆 **Prize:** {prize}\n\n🎊 **New Winner:** {new_winner.mention}\n\n'
        f'Congratulations on the reroll! You have been given the **Giveaway Winner** role for **{WINNER_ROLE_DAYS} days**! 🏅\n\n'
        f'Contact the host to claim your prize. 🎁',
        color=0xffd700
    )
    if interaction.guild.icon:
        win_embed.set_thumbnail(url=interaction.guild.icon.url)
    await interaction.response.send_message(content=new_winner.mention, embed=win_embed)

    try:
        dm = make_embed(
            '🎉 You Won a Giveaway Reroll!',
            f'Congratulations! 🎊\n\nYou were rerolled as the winner of the **{prize}** giveaway in **{interaction.guild.name}**!\n\n'
            f'You have been given the **Giveaway Winner** role for **{WINNER_ROLE_DAYS} days**! 🏅\n\n'
            f'Please contact the host to claim your prize. 🎁',
            color=0xffd700
        )
        if interaction.guild.icon:
            dm.set_thumbnail(url=interaction.guild.icon.url)
        await new_winner.send(embed=dm)
    except discord.Forbidden:
        pass

async def automod_setting_autocomplete(interaction: discord.Interaction, current: str) -> list[app_commands.Choice[str]]:
    options = ['enable', 'disable', 'links', 'spam', 'mentions', 'badwords', 'addword', 'removeword', 'settings']
    return [app_commands.Choice(name=o, value=o) for o in options if current.lower() in o.lower()]


@bot.tree.command(name='automod', description='Configure AutoMod filters (Admin only)')
@app_commands.describe(
    setting='What to configure: enable, disable, links, spam, mentions, badwords, addword, removeword, settings',
    value='Value for the setting (e.g. a bad word to add/remove, or on/off)'
)
@app_commands.autocomplete(setting=automod_setting_autocomplete)
@app_commands.checks.has_permissions(administrator=True)
async def automod_slash(interaction: discord.Interaction, setting: str, value: Optional[str] = None):
    g = str(interaction.guild.id)
    automod_db.setdefault(g, {})
    cfg = get_automod_cfg(g)

    setting = setting.lower().strip()

    if setting == 'enable':
        automod_db[g]['enabled'] = True
        save_json(AUTOMOD_FILE, automod_db)
        await interaction.response.send_message(embed=make_embed('🛡️ AutoMod Enabled', 'All active filters are now running.', color=0x00ff88), ephemeral=True)

    elif setting == 'disable':
        automod_db[g]['enabled'] = False
        save_json(AUTOMOD_FILE, automod_db)
        await interaction.response.send_message(embed=make_embed('🔴 AutoMod Disabled', 'AutoMod has been turned off.', color=0xff4444), ephemeral=True)

    elif setting in ('links', 'link'):
        state = not cfg.get('link_filter', True) if value is None else value.lower() == 'on'
        automod_db[g]['link_filter'] = state
        save_json(AUTOMOD_FILE, automod_db)
        await interaction.response.send_message(embed=make_embed('🔗 Link Filter', f'Link filter is now **{"ON" if state else "OFF"}**.', color=0x00ff88 if state else 0xff4444), ephemeral=True)

    elif setting in ('spam',):
        state = not cfg.get('spam_filter', True) if value is None else value.lower() == 'on'
        automod_db[g]['spam_filter'] = state
        save_json(AUTOMOD_FILE, automod_db)
        await interaction.response.send_message(embed=make_embed('⚡ Spam Filter', f'Spam filter is now **{"ON" if state else "OFF"}**.', color=0x00ff88 if state else 0xff4444), ephemeral=True)

    elif setting in ('mentions', 'mention'):
        state = not cfg.get('mention_filter', True) if value is None else value.lower() == 'on'
        automod_db[g]['mention_filter'] = state
        save_json(AUTOMOD_FILE, automod_db)
        await interaction.response.send_message(embed=make_embed('📢 Mention Filter', f'Mention spam filter is now **{"ON" if state else "OFF"}**.', color=0x00ff88 if state else 0xff4444), ephemeral=True)

    elif setting in ('badwords', 'badword'):
        state = not cfg.get('badword_filter', True) if value is None else value.lower() == 'on'
        automod_db[g]['badword_filter'] = state
        save_json(AUTOMOD_FILE, automod_db)
        await interaction.response.send_message(embed=make_embed('🤬 Bad Word Filter', f'Bad word filter is now **{"ON" if state else "OFF"}**.', color=0x00ff88 if state else 0xff4444), ephemeral=True)

    elif setting == 'addword':
        if not value:
            await interaction.response.send_message('Please provide a word to add.', ephemeral=True)
            return
        word = value.lower().strip()
        words = list(cfg.get('badwords', []))
        if word in words:
            await interaction.response.send_message(f'`{word}` is already in the bad word list.', ephemeral=True)
            return
        words.append(word)
        automod_db[g]['badwords'] = words
        save_json(AUTOMOD_FILE, automod_db)
        await interaction.response.send_message(embed=make_embed('✅ Word Added', f'`{word}` has been added to the bad word list.', color=0x00ff88), ephemeral=True)

    elif setting == 'removeword':
        if not value:
            await interaction.response.send_message('Please provide a word to remove.', ephemeral=True)
            return
        word = value.lower().strip()
        words = list(cfg.get('badwords', []))
        if word not in words:
            await interaction.response.send_message(f'`{word}` is not in the bad word list.', ephemeral=True)
            return
        words.remove(word)
        automod_db[g]['badwords'] = words
        save_json(AUTOMOD_FILE, automod_db)
        await interaction.response.send_message(embed=make_embed('✅ Word Removed', f'`{word}` has been removed from the bad word list.', color=0x00ff88), ephemeral=True)

    elif setting in ('settings', 'status', 'info'):
        words = cfg.get('badwords', [])
        desc = (
            f'**Status:** {"✅ Enabled" if cfg.get("enabled", True) else "🔴 Disabled"}\n\n'
            f'🔗 **Link Filter:** {"✅" if cfg.get("link_filter", True) else "❌"}\n'
            f'⚡ **Spam Filter:** {"✅" if cfg.get("spam_filter", True) else "❌"} '
            f'(threshold: {cfg.get("spam_threshold", 5)} msgs / {cfg.get("spam_window", 5)}s)\n'
            f'📢 **Mention Filter:** {"✅" if cfg.get("mention_filter", True) else "❌"} '
            f'(threshold: {cfg.get("mention_threshold", 3)} mentions)\n'
            f'🤬 **Bad Word Filter:** {"✅" if cfg.get("badword_filter", True) else "❌"}\n'
            f'⏱️ **Timeout Duration:** {cfg.get("timeout_minutes", 60)} minutes\n\n'
            f'📋 **Bad Words ({len(words)}):** '
            + (', '.join(f'`{w}`' for w in words) if words else '*none set*')
        )
        await interaction.response.send_message(embed=make_embed('🛡️ AutoMod Settings', desc, color=0x5865f2), ephemeral=True)

    else:
        await interaction.response.send_message(
            'Valid settings: `enable`, `disable`, `links`, `spam`, `mentions`, `badwords`, `addword`, `removeword`, `settings`',
            ephemeral=True
        )


@bot.tree.command(name="help", description="Show all available commands")
async def help_slash(interaction: discord.Interaction):
    embed = make_embed('🤖 Bot Commands Panel', 'Here are all available commands:', color=0x00ff00)
    
    embed.add_field(
        name='🔨 Moderation Commands',
        value=(
            '`/mute <member> [minutes]` - Mute a member\n'
            '`/timeout <member> [minutes]` - Timeout a member\n'
            '`/kick <member> [reason]` - Kick a member\n'
            '`/ban <member> [days] [reason]` - Ban a member\n'
            '`/warn <member> [reason]` - Warn a member (DMs user, logs, auto-actions)\n'
            '`/warnings <member>` - View member warnings\n'
            '`/removewarn <member> <index>` - Remove a specific warning\n'
            '`/clearwarnings <member>` - Clear all warnings (Admin)\n'
            '`/purge <amount> [member]` - Delete messages'
        ),
        inline=False
    )
    
    embed.add_field(
        name='📊 Utility & Tracking',
        value=(
            '`/invites [member]` - Check invites or leaderboard\n'
            '`/leaderboard` - Show top 10 invite leaderboard\n'
            '`/reset` - Reset all invite data (Admin)\n'
            '`/giveaway <minutes> <winners> <prize> [role]` - Start giveaway\n'
            '`/greroll <name>` - Reroll a winner for an ended giveaway by name'
        ),
        inline=False
    )
    
    embed.add_field(
        name='👥 Role Management',
        value=(
            '`/addrole <member> <role>` - Give role to member\n'
            '`/removerole <member> <role>` - Remove role from member\n'
            '`/staffadd <member>` - Add staff roles (Admin)\n'
            '`/staffconfig <action> [role]` - Configure staff roles'
        ),
        inline=False
    )
    
    embed.add_field(
        name='🛡️ Bot Permissions & Security',
        value=(
            '`/botpermissions <action> [role]` - Configure bot access\n'
            '`/botpanel` - Show permission management panel\n'
            '`/automod <setting> [value]` - Configure AutoMod filters\n'
            '• **Invite Tracking** - Automatic invite monitoring\n'
            '• **DM Notifications** - Users get notified of mod actions'
        ),
        inline=False
    )
    embed.add_field(
        name='🤖 AutoMod (auto-enforced)',
        value=(
            '🔗 **Links** — deleted + 1hr timeout + warning\n'
            '⚡ **Spam** — 5+ msgs in 5s → same punishment\n'
            '📢 **Mention spam** — 3+ pings in one msg → same punishment\n'
            '🤬 **Bad words** — deleted + 1hr timeout + warning\n'
            '*Mods are immune. Use `/automod settings` to configure.*'
        ),
        inline=False
    )
    
    embed.add_field(
        name='🔧 Text Commands (prefix: !)',
        value=(
            '`!addresponder <trigger> <response>` - Add auto response\n'
            '`!listresponders` - List all auto responses\n'
            '`!removeresponder <index>` - Remove auto response\n'
            '`!resetleaderboard` - Reset invite leaderboard\n'
            '`!clearwarnings <member>` - Clear member warnings\n'
            '`!unmute <member>` - Unmute a member'
        ),
        inline=False
    )
    
    embed.set_footer(text='🎯 18 Slash Commands Available • Use / to see all commands\nMade by Tanish14')
    await interaction.response.send_message(embed=embed)

# Missing Slash Commands
@bot.tree.command(name="reset", description="Reset all invite data (Admin only)")
async def reset_slash(interaction: discord.Interaction):
    if not interaction.guild:
        await interaction.response.send_message("This command can only be used in a server.")
        return
        
    # Check bot permissions first
    if not has_bot_permission(interaction.user):
        await interaction.response.send_message("❌ You don't have permission to use this bot.", ephemeral=True)
        return
        
    if not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message("You need administrator permissions to use this command.")
        return
    
    g = str(interaction.guild.id)
    invites_db[g] = {}
    save_json(INVITES_FILE, invites_db)
    await interaction.response.send_message('✅ All invite data has been reset!')

@bot.tree.command(name="leaderboard", description="Show top 10 invite leaderboard")
async def leaderboard_slash(interaction: discord.Interaction):
    if not interaction.guild:
        await interaction.response.send_message("This command can only be used in a server.")
        return
        
    g = str(interaction.guild.id)
    data = invites_db.get(g, {})
    
    if not data:
        await interaction.response.send_message('No invite data found for this server.')
        return
    
    # Falcon-style format
    processed_data = []
    for uid, user_data in data.items():
        if isinstance(user_data, int):  # Handle old format
            total = user_data
            user_data = {'regular': user_data, 'bonus': 0, 'fake': 0, 'left': 0}
        else:
            total = user_data.get('regular', 0) + user_data.get('bonus', 0)
        processed_data.append((uid, total, user_data))
    
    sorted_invites = sorted(processed_data, key=lambda x: x[1], reverse=True)
    desc = ''
    for i, (uid, total_invites, user_data) in enumerate(sorted_invites[:10], 1):
        user = interaction.guild.get_member(int(uid))
        if user:
            joins = user_data.get('regular', 0) + user_data.get('bonus', 0)
            leaves = user_data.get('left', 0)
            fakes = user_data.get('fake', 0)
            rejoins = 0
            
            desc += f'**#{i}** {user.mention} • **{total_invites} Invites** ({joins} Joins, {leaves} Leaves, {fakes} Fakes, {rejoins} Rejoins)\n'
        else:
            desc += f'**#{i}** Unknown User • **{total_invites} Invites**\n'
    
    embed = make_embed('🏆 Invite Leaderboard', desc)
    embed.add_field(
        name='📊 Server Statistics',
        value=f'Page 1/1 | Create live leaderboards using {bot.user.name} Premium',
        inline=False
    )
    
    await interaction.response.send_message(embed=embed)

@bot.tree.command(name="staffadd", description="Add staff roles to a user (Admin only)")
@app_commands.describe(member="Member to add staff roles to")
async def staffadd_slash(interaction: discord.Interaction, member: discord.Member):
    if not interaction.guild:
        await interaction.response.send_message("This command can only be used in a server.")
        return
        
    if not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message("You need administrator permissions to use this command.")
        return
    
    g = str(interaction.guild.id)
    staff_roles = staff_roles_db.get(g, [])
    
    if not staff_roles:
        await interaction.response.send_message('No staff roles configured. Use `/staffconfig` to set them up.')
        return
    
    added_roles = []
    
    for role_id in staff_roles:
        role = interaction.guild.get_role(int(role_id))
        if role and role not in member.roles:
            try:
                await member.add_roles(role, reason=f'Staff promotion by {interaction.user}')
                added_roles.append(role.mention)
            except Exception:
                pass
    
    if added_roles:
        embed = make_embed('🎯 Staff Roles Added', f'Added roles to {member.mention}:\n{chr(10).join(added_roles)}')
        await interaction.response.send_message(embed=embed)
        
        # Log the action
        log_channel = bot.get_channel(1407004168580894874)
        if log_channel and isinstance(log_channel, discord.TextChannel):
            log_embed = make_embed('Staff Promoted', f'**Member:** {member.mention}\n**Roles Added:** {chr(10).join(added_roles)}\n**Moderator:** {interaction.user.mention}')
            await log_channel.send(embed=log_embed)
    else:
        await interaction.response.send_message(f'{member.mention} already has all staff roles.')

@bot.tree.command(name="staffconfig", description="Configure staff roles (Admin only)")
@app_commands.describe(action="add/remove/list staff roles", role="Role to add or remove")
async def staffconfig_slash(interaction: discord.Interaction, action: str, role: discord.Role = None):
    if not interaction.guild:
        await interaction.response.send_message("This command can only be used in a server.")
        return
        
    if not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message("You need administrator permissions to use this command.")
        return
    
    g = str(interaction.guild.id)
    staff_roles_db.setdefault(g, [])
    
    if action.lower() == 'add' and role:
        if role.id not in staff_roles_db[g]:
            staff_roles_db[g].append(role.id)
            save_json(STAFF_ROLES_FILE, staff_roles_db)
            await interaction.response.send_message(f'✅ Added {role.mention} to staff roles.')
        else:
            await interaction.response.send_message(f'{role.mention} is already a staff role.')
    elif action.lower() == 'remove' and role:
        if role.id in staff_roles_db[g]:
            staff_roles_db[g].remove(role.id)
            save_json(STAFF_ROLES_FILE, staff_roles_db)
            await interaction.response.send_message(f'✅ Removed {role.mention} from staff roles.')
        else:
            await interaction.response.send_message(f'{role.mention} is not a staff role.')
    elif action.lower() == 'list':
        if staff_roles_db[g]:
            role_mentions = [f'<@&{role_id}>' for role_id in staff_roles_db[g]]
            embed = make_embed('👥 Staff Roles', '\n'.join(role_mentions))
            await interaction.response.send_message(embed=embed)
        else:
            await interaction.response.send_message('No staff roles configured.')
    else:
        await interaction.response.send_message('Usage: `/staffconfig <add/remove/list> [role]`')

@bot.tree.command(name="addrole", description="Give a role to a member")
@app_commands.describe(member="Member to give role to", role="Role to give")
async def addrole_slash(interaction: discord.Interaction, member: discord.Member, role: discord.Role):
    if not interaction.guild:
        await interaction.response.send_message("This command can only be used in a server.")
        return
        
    if not interaction.user.guild_permissions.manage_roles:
        await interaction.response.send_message("You need manage roles permission to use this command.")
        return
        
    if role in member.roles:
        await interaction.response.send_message(f'{member.mention} already has the {role.mention} role.')
        return
        
    try:
        await member.add_roles(role, reason=f'Role added by {interaction.user}')
        await interaction.response.send_message(f'✅ Successfully gave {role.mention} to {member.mention}')
        
        # Log the action
        log_channel = bot.get_channel(1407004168580894874)
        if log_channel and isinstance(log_channel, discord.TextChannel):
            embed = make_embed('Role Added', f'**Member:** {member.mention}\n**Role:** {role.mention}\n**Moderator:** {interaction.user.mention}')
            await log_channel.send(embed=embed)
    except Exception as e:
        await interaction.response.send_message(f'Failed to add role: {e}')

@bot.tree.command(name="removerole", description="Remove a role from a member")
@app_commands.describe(member="Member to remove role from", role="Role to remove")
async def removerole_slash(interaction: discord.Interaction, member: discord.Member, role: discord.Role):
    if not interaction.guild:
        await interaction.response.send_message("This command can only be used in a server.")
        return
        
    if not interaction.user.guild_permissions.manage_roles:
        await interaction.response.send_message("You need manage roles permission to use this command.")
        return
        
    if role not in member.roles:
        await interaction.response.send_message(f'{member.mention} does not have the {role.mention} role.')
        return
        
    try:
        await member.remove_roles(role, reason=f'Role removed by {interaction.user}')
        await interaction.response.send_message(f'✅ Successfully removed {role.mention} from {member.mention}')
        
        # Log the action
        log_channel = bot.get_channel(1407004168580894874)
        if log_channel and isinstance(log_channel, discord.TextChannel):
            embed = make_embed('Role Removed', f'**Member:** {member.mention}\n**Role:** {role.mention}\n**Moderator:** {interaction.user.mention}')
            await log_channel.send(embed=embed)
    except Exception as e:
        await interaction.response.send_message(f'Failed to remove role: {e}')

@bot.tree.command(name="purge", description="Bulk delete messages")
@app_commands.describe(amount="Number of messages to delete", member="Delete only messages from this member (optional)")
async def purge_slash(interaction: discord.Interaction, amount: int, member: Optional[discord.Member] = None):
    if not interaction.guild:
        await interaction.response.send_message("This command can only be used in a server.")
        return
        
    # Check bot permissions first
    if not has_bot_permission(interaction.user):
        await interaction.response.send_message("❌ You don't have permission to use this bot.", ephemeral=True)
        return
        
    if not interaction.user.guild_permissions.manage_messages:
        await interaction.response.send_message("You need manage messages permission to use this command.")
        return
        
    if amount > 100:
        await interaction.response.send_message('Cannot delete more than 100 messages at once.')
        return
        
    def check(message):
        if member:
            return message.author == member
        return True
    
    try:
        await interaction.response.defer()
        deleted = await interaction.channel.purge(limit=amount, check=check)
        embed = make_embed('Messages Purged', f'Deleted {len(deleted)} messages')
        await interaction.followup.send(embed=embed, ephemeral=True)
    except Exception as e:
        await interaction.followup.send(f'Failed to purge messages: {e}', ephemeral=True)

# Bot Permission Management Commands
@bot.tree.command(name="botpermissions", description="Configure which roles can use the bot (Admin only)")
@app_commands.describe(action="add/remove/list/clear bot access roles", role="Role to add or remove")
async def botpermissions_slash(interaction: discord.Interaction, action: str, role: discord.Role = None):
    if not interaction.guild:
        await interaction.response.send_message("This command can only be used in a server.")
        return
        
    if not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message("❌ You need administrator permissions to configure bot permissions.")
        return
    
    g = str(interaction.guild.id)
    bot_permissions_db.setdefault(g, [])
    
    if action.lower() == 'add' and role:
        if role.id not in bot_permissions_db[g]:
            bot_permissions_db[g].append(role.id)
            save_json(BOT_PERMISSIONS_FILE, bot_permissions_db)
            embed = make_embed('✅ Bot Permission Added', f'Members with {role.mention} can now use this bot.')
            await interaction.response.send_message(embed=embed)
        else:
            await interaction.response.send_message(f'{role.mention} already has bot access.')
    
    elif action.lower() == 'remove' and role:
        if role.id in bot_permissions_db[g]:
            bot_permissions_db[g].remove(role.id)
            save_json(BOT_PERMISSIONS_FILE, bot_permissions_db)
            embed = make_embed('✅ Bot Permission Removed', f'Members with {role.mention} can no longer use this bot.')
            await interaction.response.send_message(embed=embed)
        else:
            await interaction.response.send_message(f'{role.mention} does not have bot access.')
    
    elif action.lower() == 'list':
        if bot_permissions_db[g]:
            role_mentions = []
            for role_id in bot_permissions_db[g]:
                role_obj = interaction.guild.get_role(role_id)
                if role_obj:
                    role_mentions.append(role_obj.mention)
            
            if role_mentions:
                embed = make_embed('🛡️ Bot Access Roles', f'These roles can use the bot:\n{chr(10).join(role_mentions)}')
            else:
                embed = make_embed('🛡️ Bot Access Roles', 'No valid roles found (some may have been deleted)')
            await interaction.response.send_message(embed=embed)
        else:
            embed = make_embed('🛡️ Bot Access Roles', '**Everyone** can use the bot (no restrictions set)')
            await interaction.response.send_message(embed=embed)
    
    elif action.lower() == 'clear':
        bot_permissions_db[g] = []
        save_json(BOT_PERMISSIONS_FILE, bot_permissions_db)
        embed = make_embed('✅ Permissions Cleared', 'All role restrictions removed. **Everyone** can now use the bot.')
        await interaction.response.send_message(embed=embed)
    
    else:
        embed = make_embed('❌ Invalid Usage', '**Usage:** `/botpermissions <add/remove/list/clear> [role]`\n\n**Examples:**\n• `/botpermissions add @Staff` - Give Staff role bot access\n• `/botpermissions remove @Helper` - Remove Helper role access\n• `/botpermissions list` - Show all roles with access\n• `/botpermissions clear` - Remove all restrictions')
        await interaction.response.send_message(embed=embed)

@bot.tree.command(name="botpanel", description="Show bot permission management panel")
async def botpanel_slash(interaction: discord.Interaction):
    if not interaction.guild:
        await interaction.response.send_message("This command can only be used in a server.")
        return
        
    if not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message("❌ You need administrator permissions to view the bot panel.")
        return
    
    g = str(interaction.guild.id)
    allowed_roles = bot_permissions_db.get(g, [])
    
    embed = make_embed('🤖 Bot Permission Panel', '')
    
    if allowed_roles:
        role_list = []
        for role_id in allowed_roles:
            role = interaction.guild.get_role(role_id)
            if role:
                role_list.append(f'• {role.mention}')
        
        if role_list:
            embed.add_field(
                name='🛡️ Roles with Bot Access',
                value='\n'.join(role_list),
                inline=False
            )
        else:
            embed.add_field(
                name='🛡️ Bot Access Status', 
                value='No valid roles configured (some may have been deleted)',
                inline=False
            )
    else:
        embed.add_field(
            name='🛡️ Bot Access Status',
            value='**No restrictions** - Everyone can use the bot',
            inline=False
        )
    
    embed.add_field(
        name='⚙️ Management Commands',
        value=(
            '• `/botpermissions add @role` - Give role bot access\n'
            '• `/botpermissions remove @role` - Remove role access\n'
            '• `/botpermissions list` - List all access roles\n'
            '• `/botpermissions clear` - Remove all restrictions'
        ),
        inline=False
    )
    
    embed.add_field(
        name='ℹ️ How it Works',
        value=(
            '• **No roles set** = Everyone can use bot\n'
            '• **Roles configured** = Only those roles can use bot\n'
            '• **Administrators** = Always have access'
        ),
        inline=False
    )
    
    await interaction.response.send_message(embed=embed)

@bot.command(name='panel')
async def panel_cmd(ctx):
    embed = make_embed('🤖 Bot Commands Panel', 'Here are all available commands:', color=0x00ff00)
    
    embed.add_field(
        name='🔨 Moderation Commands',
        value=(
            '`/mute <member> [minutes]` - Mute a member\n'
            '`/timeout <member> [minutes]` - Timeout a member\n'
            '`/kick <member> [reason]` - Kick a member\n'
            '`/ban <member> [days] [reason]` - Ban a member\n'
            '`/warn <member> [reason]` - Warn a member\n'
            '`/warnings <member>` - View member warnings'
        ),
        inline=False
    )
    
    embed.add_field(
        name='📊 Utility Commands',
        value=(
            '`/invites [member]` - Check invites or leaderboard\n'
            '`/giveaway <minutes> <winners> <prize> [description]` - Start giveaway'
        ),
        inline=False
    )
    
    embed.add_field(
        name='🔧 Text Commands (prefix: !)',
        value=(
            '`!addresponder <trigger> <response>` - Add auto response\n'
            '`!listresponders` - List all auto responses\n'
            '`!removeresponder <index>` - Remove auto response\n'
            '`!resetleaderboard` - Reset invite leaderboard\n'
            '`!clearwarnings <member>` - Clear member warnings\n'
            '`!unmute <member>` - Unmute a member'
        ),
        inline=False
    )
    
    embed.add_field(
        name='🛡️ Auto-Protection Features',
        value=(
            '🔗 **Link Filter** — auto-deleted + 1hr timeout + warning\n'
            '⚡ **Spam Filter** — 5+ msgs/5s → 1hr timeout + warning\n'
            '📢 **Mention Spam** — 3+ pings → 1hr timeout + warning\n'
            '🤬 **Bad Word Filter** — auto-deleted + 1hr timeout + warning\n'
            '• **Invite Tracking** - Automatic invite monitoring\n'
            '• **DM Notifications** - Users get notified of mod actions\n'
            '*Use `/automod settings` to view and configure all filters.*'
        ),
        inline=False
    )
    
    embed.set_footer(text='Use / to see slash commands • Use ! for text commands\nMade by Tanish14')
    await ctx.send(embed=embed)

@bot.command(name='kick')
@commands.has_permissions(kick_members=True)
async def kick(ctx, member: discord.Member, *, reason: Optional[str] = None):
    # Send DM to the user before kicking
    try:
        reason_text = reason or "No reason provided"
        dm_embed = make_embed('You have been kicked', f'You have been kicked from **{ctx.guild.name}** by {ctx.author.mention}.\nReason: {reason_text}', color=0xff0000)
        await member.send(embed=dm_embed)
    except discord.Forbidden:
        pass  # User has DMs disabled
    
    try:
        await member.kick(reason=reason)
        await ctx.send(embed=make_embed('Kicked', f'{member.mention} has been kicked. Reason: {reason}'))
    except Exception as e:
        await ctx.send(f'Failed to kick: {e}')

@bot.command(name='ban')
@commands.has_permissions(ban_members=True)
async def ban(ctx, member: discord.Member, days: int = 0, *, reason: Optional[str] = None):
    # Send DM to the user before banning
    try:
        reason_text = reason or "No reason provided"
        dm_embed = make_embed('You have been banned', f'You have been banned from **{ctx.guild.name}** by {ctx.author.mention}.\nReason: {reason_text}', color=0xff0000)
        await member.send(embed=dm_embed)
    except discord.Forbidden:
        pass  # User has DMs disabled
    
    try:
        await ctx.guild.ban(member, reason=reason, delete_message_days=days)
        await ctx.send(embed=make_embed('Banned', f'{member.mention} has been banned. Reason: {reason}'))
    except Exception as e:
        await ctx.send(f'Failed to ban: {e}')

@bot.command(name='timeout')
@commands.has_permissions(moderate_members=True)
async def timeout(ctx, member: discord.Member, minutes: int = 10):
    # Send DM to the user before timeout
    try:
        dm_embed = make_embed('You have been timed out', f'You have been timed out in **{ctx.guild.name}** for **{minutes} minutes** by {ctx.author.mention}.', color=0xff9500)
        await member.send(embed=dm_embed)
    except discord.Forbidden:
        pass  # User has DMs disabled
    
    until = discord.utils.utcnow() + timedelta(minutes=minutes)
    try:
        # Use Discord's actual timeout feature (not mute role)
        await member.edit(timed_out_until=until, reason=f'Timed out by {ctx.author.display_name}')
        await ctx.send(embed=make_embed('Timed out', f'{member.mention} has been timed out for {minutes} minutes.'))
        print(f'Successfully timed out {member.display_name} for {minutes} minutes')
    except discord.HTTPException as e:
        await ctx.send(f'Timeout failed: {e}. Make sure the bot has "Timeout Members" permission.')
        print(f'Timeout failed for {member.display_name}: {e}')
    except Exception as e:
        await ctx.send(f'Timeout failed: {e}')
        print(f'Unexpected timeout error for {member.display_name}: {e}')

WINNER_ROLE_ID = 1409943475679658056
WINNER_ROLE_DAYS = 7

async def _get_or_create_winner_role(guild: discord.Guild) -> Optional[discord.Role]:
    role = guild.get_role(WINNER_ROLE_ID)
    if not role:
        role = discord.utils.get(guild.roles, name='Giveaway Winner')
    return role

async def _schedule_winner_role_removal(guild_id: int, member_id: int, days: int):
    await asyncio.sleep(days * 86400)
    guild = bot.get_guild(guild_id)
    if not guild:
        return
    member = guild.get_member(member_id)
    if not member:
        return
    role = guild.get_role(WINNER_ROLE_ID)
    if role and role in member.roles:
        try:
            await member.remove_roles(role, reason=f'Giveaway Winner role expired after {days} days')
        except Exception:
            pass

async def _give_winner_role(guild: discord.Guild, members: list[discord.Member]):
    role = await _get_or_create_winner_role(guild)
    if not role:
        return
    for member in members:
        try:
            await member.add_roles(role, reason='Giveaway winner')
            asyncio.create_task(_schedule_winner_role_removal(guild.id, member.id, WINNER_ROLE_DAYS))
        except Exception:
            pass

async def _remove_winner_role(guild: discord.Guild, member_ids: list[int]):
    role = guild.get_role(WINNER_ROLE_ID)
    if not role:
        return
    for uid in member_ids:
        member = guild.get_member(uid)
        if member and role in member.roles:
            try:
                await member.remove_roles(role, reason='Giveaway rerolled — winner role transferred')
            except Exception:
                pass

async def _finish_giveaway(channel: discord.abc.Messageable, msg_id: int, prize: str, winners_count: int, guild_id: int = None):
    if guild_id is None and hasattr(channel, 'guild'):
        guild_id = channel.guild.id

    guild = bot.get_guild(guild_id) if guild_id else getattr(channel, 'guild', None)

    participant_ids = []
    if guild_id:
        data = active_giveaways.get(str(guild_id), {}).get(str(msg_id), {})
        participant_ids = data.get('participants', [])

    if not participant_ids:
        await channel.send(embed=make_embed('🎉 Giveaway Ended', f'**Prize:** {prize}\n\nNo one entered — giveaway cancelled.', color=0x888888))
        return

    chosen_ids = random.sample(participant_ids, min(winners_count, len(participant_ids)))
    winner_members = []
    for uid in chosen_ids:
        member = guild.get_member(uid) if guild else None
        if member:
            winner_members.append(member)

    if not winner_members:
        await channel.send(embed=make_embed('🎉 Giveaway Ended', f'**Prize:** {prize}\n\nCould not resolve winners.', color=0x888888))
        return

    mention_list = ', '.join(w.mention for w in winner_members)

    win_embed = make_embed(
        '🎉 Giveaway Ended! 🎉',
        f'🏆 **Prize:** {prize}\n\n'
        f'🎊 **Winner{"s" if len(winner_members) > 1 else ""}:** {mention_list}\n\n'
        f'Congratulations! Contact the host to claim your prize. 🎁',
        color=0xffd700
    )
    await channel.send(content=mention_list, embed=win_embed)

    if guild:
        await _give_winner_role(guild, winner_members)

    for winner in winner_members:
        try:
            dm = make_embed(
                '🎉 You Won a Giveaway!',
                f'Congratulations! 🎊\n\nYou won the **{prize}** giveaway'
                f'{f" in **{guild.name}**" if guild else ""}!\n\n'
                f'You have been given the **Giveaway Winner** role for **{WINNER_ROLE_DAYS} days**! 🏅\n\n'
                f'Please contact the host to claim your prize. 🎁',
                color=0xffd700
            )
            await winner.send(embed=dm)
        except discord.Forbidden:
            pass

    try:
        msg = await channel.fetch_message(msg_id)
        ended_view = discord.ui.View()
        ended_view.add_item(discord.ui.Button(
            label='Giveaway Ended',
            style=discord.ButtonStyle.secondary,
            disabled=True,
            emoji='🔒'
        ))
        await msg.edit(view=ended_view)
    except Exception:
        pass

    if guild_id:
        g = str(guild_id)
        gdata = active_giveaways.get(g, {}).get(str(msg_id), {})
        ended_giveaways_db.setdefault(g, {})
        ended_giveaways_db[g][str(msg_id)] = {
            'prize': prize,
            'name': gdata.get('name', prize),
            'winners_count': winners_count,
            'current_winners': [m.id for m in winner_members],
            'participants': gdata.get('participants', []),
            'ended_at': datetime.utcnow().isoformat(),
        }
        save_json(ENDED_GIVEAWAYS_FILE, ended_giveaways_db)


@bot.command(name='giveaway')
@commands.has_permissions(manage_guild=True)
async def start_giveaway(ctx, minutes: int, winners: int, prize: str, role: Optional[discord.Role] = None, name: Optional[str] = None, *, description: Optional[str] = None):
    if minutes <= 0 or winners <= 0:
        await ctx.send('Invalid parameters.')
        return

    end_time = datetime.utcnow() + timedelta(minutes=minutes)
    embed_title = f'🎉 {name} 🎉' if name else '🎉 Giveaway Started! 🎉'
    giveaway_description = (
        f'🎁 **Prize:** {prize}\n'
        f'👤 **Hosted by:** {ctx.author.mention}\n'
        f'⏰ **Ends:** {end_time.strftime("%b %d at %H:%M UTC")}\n'
        f'🏆 **Winners:** {winners}\n'
    )
    if role:
        giveaway_description += f'🔒 **Required Role:** {role.mention}\n'
    if description:
        giveaway_description += f'📋 **Description:** {description}\n'
    giveaway_description += '\n**Press 🎉 Join Giveaway to enter!**'

    embed = make_embed(embed_title, giveaway_description)
    embed.set_footer(text=f'Winners: {winners} • Ends {end_time.strftime("%b %d at %H:%M UTC")}\nMade by Tanish14')
    if ctx.guild.icon:
        embed.set_thumbnail(url=ctx.guild.icon.url)
    msg = await ctx.send(embed=embed)

    g = str(ctx.guild.id)
    active_giveaways.setdefault(g, {})
    active_giveaways[g][str(msg.id)] = {
        'prize': prize,
        'name': name or '',
        'host': ctx.author.id,
        'end_time': end_time.isoformat(),
        'winners': winners,
        'description': description or '',
        'required_role_id': role.id if role else None,
        'channel_id': ctx.channel.id,
        'participants': []
    }
    save_json(GIVEAWAYS_FILE, active_giveaways)

    view = make_giveaway_view(msg.id, ctx.guild.id)
    await msg.edit(view=view)
    display = name if name else prize
    await ctx.send(f'🎉 **{display}** giveaway has started! Click the button above to enter!', delete_after=12)
    asyncio.create_task(_delayed_finish_giveaway(ctx.channel, msg.id, minutes, prize, winners, ctx.guild.id))


async def _delayed_finish_giveaway(channel, msg_id, minutes, prize, winners, guild_id=None):
    await asyncio.sleep(minutes * 60)
    await _finish_giveaway(channel, msg_id, prize, winners, guild_id)
    try:
        g = str(guild_id or channel.guild.id)
        active_giveaways[g].pop(str(msg_id), None)
        save_json(GIVEAWAYS_FILE, active_giveaways)
    except Exception:
        pass

@tasks.loop(minutes=1)
async def giveaway_checkpoint():
    global active_giveaways
    active_giveaways = load_json(GIVEAWAYS_FILE)
    now = datetime.utcnow()
    for g, giveaways in list(active_giveaways.items()):
        guild = bot.get_guild(int(g))
        if not guild:
            continue
        for msgid, data in list(giveaways.items()):
            end = datetime.fromisoformat(data['end_time'])
            if end <= now:
                try:
                    channel_id = data.get('channel_id')
                    channel = bot.get_channel(int(channel_id)) if channel_id else None
                    if not channel:
                        channel = next((c for c in guild.text_channels if c.permissions_for(guild.me).send_messages), None)
                    if not channel:
                        continue
                    await _finish_giveaway(channel, int(msgid), data.get('prize'), data.get('winners', 1), int(g))
                except Exception as e:
                    print('giveaway resume error', e)
                active_giveaways[g].pop(msgid, None)
    save_json(GIVEAWAYS_FILE, active_giveaways)

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.MissingPermissions):
        await ctx.send('You do not have permission to run this command.')
    elif isinstance(error, commands.MissingRequiredArgument):
        # Provide specific help based on the command
        cmd_name = ctx.command.name
        usage_examples = {
            'addresponder': '**Usage:** `!addresponder <trigger> <response>`\n**Example:** `!addresponder hello Hi there!`',
            'removeresponder': '**Usage:** `!removeresponder <index>`\n**Example:** `!removeresponder 1`',
            'warn': '**Usage:** `!warn <member> [reason]`\n**Example:** `!warn @user Breaking rules`',
            'mute': '**Usage:** `!mute <member> [reason]`\n**Example:** `!mute @user Spamming`',
            'kick': '**Usage:** `!kick <member> [reason]`\n**Example:** `!kick @user Violation of rules`',
            'ban': '**Usage:** `!ban <member> [reason]`\n**Example:** `!ban @user Serious violation`',
            'timeout': '**Usage:** `!timeout <member> <minutes> [reason]`\n**Example:** `!timeout @user 10 Calm down`',
            'addinvites': '**Usage:** `!addinvites <member> <amount>`\n**Example:** `!addinvites @user 5`',
            'removeinvites': '**Usage:** `!removeinvites <member> <amount>`\n**Example:** `!removeinvites @user 2`',
            'invitereward': '**Usage:** `!invitereward <milestone> <role>`\n**Example:** `!invitereward 10 @VIP`',
            'giveaway': '**Usage:** `!giveaway <minutes> <winners> <prize>`\n**Example:** `!giveaway 60 1 Discord Nitro`',
            'advgiveaway': '**Usage:** `!advgiveaway <minutes> <winners> <prize> [requirements]`\n**Example:** `!advgiveaway 120 2 $50 Gift Card Must be level 5+`',
            'massban': '**Usage:** `!massban <user_id1> <user_id2> ...`\n**Example:** `!massban 123456789 987654321`',
            'antinuke': '**Usage:** `!antinuke <enable/disable>`\n**Example:** `!antinuke enable`',
            'antinukewhitelist': '**Usage:** `!antinukewhitelist <add/remove/list> [@member]`\n**Example:** `!antinukewhitelist add @trusted_user`'
        }
        
        if cmd_name in usage_examples:
            embed = make_embed('❌ Missing Arguments', f'{usage_examples[cmd_name]}')
            await ctx.send(embed=embed)
        else:
            await ctx.send(f'Missing arguments for `!{cmd_name}`. Use `!help` to see all commands.')
    elif isinstance(error, commands.CommandNotFound):
        return
    else:
        await ctx.send(f'An error occurred: {error}')
        raise error

# ─── Review & Order System ───────────────────────────────────────────────────

def make_stars(rating: int) -> str:
    return '⭐' * rating + '☆' * (5 - rating)

def make_progress_bar(percent: int) -> str:
    filled = round(percent / 10)
    empty = 10 - filled
    bar = '🟩' * filled + '⬛' * empty
    return f'{bar}\n**{percent}%**'

def is_staff(member: discord.Member) -> bool:
    if member.guild_permissions.administrator or member.guild_permissions.manage_guild:
        return True
    g = str(member.guild.id)
    staff_roles = staff_roles_db.get(g, [])
    return any(role.id in staff_roles for role in member.roles)

def generate_order_id() -> str:
    max_num = 0
    for guild_orders in orders_db.values():
        for o in guild_orders:
            oid = o.get('order_id', '')
            if oid.startswith('TS'):
                try:
                    max_num = max(max_num, int(oid[2:]))
                except ValueError:
                    pass
    return f'TS{max_num + 1}'

def build_order_embed(guild, customer: discord.Member, product: str, payment: str,
                      target_completion: int, status: str, progress: int,
                      order_id: str, review_text: Optional[str] = None,
                      rating: int = 5, image_url: Optional[str] = None) -> discord.Embed:
    stars = make_stars(rating)
    progress_bar = make_progress_bar(progress)
    payment_icons = {
        'Binance': '💛 Binance', 'PayPal': '🔵 PayPal',
        'Bank Transfer': '🏦 Bank Transfer', 'UPI': '📱 UPI',
        'Crypto Coin': '🪙 Crypto Coin', 'Paytm': '💙 Paytm',
    }
    payment_display = payment_icons.get(payment, payment)
    status_display = {
        'Processing': '🔄 Processing.',
        'In Progress': '⚙️ In Progress.',
        'Completed': '✅ Completed.',
    }.get(status, status)
    target_display = f'**{target_completion}d** — {target_completion} day{"s" if target_completion != 1 else ""}'

    embed = discord.Embed(
        title='🔧 Order Automated Verification',
        description=(
            '**A new order process is active in the cloud.**\n'
            'Customer identity and payment verified.'
        ),
        color=0x00C851,
        timestamp=datetime.utcnow()
    )
    embed.set_author(
        name=f'{guild.name} • Secure Commerce',
        icon_url=guild.icon.url if guild.icon else None
    )
    import os as _os
    use_local = _os.path.exists(ORDER_THUMBNAIL_PATH)
    gif_ref = f'attachment://{ORDER_THUMBNAIL_FILENAME}' if use_local else ORDER_THUMBNAIL_GIF
    if image_url:
        embed.set_thumbnail(url=gif_ref)
        embed.set_image(url=image_url)
    else:
        embed.set_image(url=gif_ref)
    embed.add_field(name='🆔 Order ID', value=f'`{order_id}`', inline=True)
    embed.add_field(name='👤 Customer', value=customer.mention, inline=True)
    embed.add_field(name='📦 Product', value=f'**{product}**', inline=True)
    embed.add_field(name='💳 Payment', value=payment_display, inline=True)
    embed.add_field(name='📅 Target Completion', value=target_display, inline=True)
    embed.add_field(name='📊 Current Status', value=status_display, inline=True)
    embed.add_field(name='📈 Progress', value=progress_bar, inline=True)
    if review_text:
        embed.add_field(name='⭐ Verified Review', value=f'*{review_text}*\n{stars}', inline=False)
    embed.set_footer(text='Made by Tanish14')
    return embed


@bot.tree.command(name='review', description='Leave a customer review (open to everyone)')
@app_commands.describe(
    rating='Your rating from 1 to 5 stars',
    product='Product or service you are reviewing',
    review_text='Your review message',
    image_url='Optional image URL to attach to the review'
)
async def review_slash(
    interaction: discord.Interaction,
    rating: app_commands.Range[int, 1, 5],
    product: str,
    review_text: str,
    image_url: Optional[str] = None
):
    if not interaction.guild:
        await interaction.response.send_message('This command can only be used in a server.', ephemeral=True)
        return

    stars = make_stars(rating)

    embed = discord.Embed(
        title='⭐ Customer Review',
        color=0xFFD700,
        timestamp=datetime.utcnow()
    )
    embed.set_thumbnail(url=ORDER_THUMBNAIL_GIF)
    embed.add_field(name='Rating:', value=f'**{rating}/5**\n{stars}', inline=True)
    embed.add_field(name='Customer:', value=interaction.user.mention, inline=True)
    if review_text:
        embed.add_field(name='Review:', value=f'*{review_text}*', inline=False)
    if image_url:
        embed.set_image(url=image_url)
    embed.set_footer(text=f'{product} • Verified Purchase • Order Confirmed\nMade by Tanish14')

    review_channel = bot.get_channel(REVIEW_CHANNEL_ID)

    if review_channel and isinstance(review_channel, discord.TextChannel):
        await review_channel.send(embed=embed)
        if review_channel.id != interaction.channel_id:
            await interaction.response.send_message(
                f'✅ Your review has been posted in {review_channel.mention}!', ephemeral=True
            )
        else:
            await interaction.response.send_message('✅ Review posted!', ephemeral=True)
    else:
        await interaction.response.send_message(embed=embed)

    g = str(interaction.guild.id)
    reviews_db.setdefault(g, [])
    reviews_db[g].append({
        'user_id': interaction.user.id,
        'rating': rating,
        'product': product,
        'review': review_text,
        'timestamp': datetime.utcnow().isoformat()
    })
    save_json(REVIEWS_FILE, reviews_db)


@bot.tree.command(name='orderplaced', description='Post an order verification card (Staff only)')
@app_commands.describe(
    customer='The customer who placed the order',
    product='Product or service ordered',
    payment='Payment method used by the customer',
    target_completion='How many days until order completion',
    review_text='Optional customer review or notes',
    rating='Star rating 1–5 (default 5)',
    status='Current order status (default: Processing)',
    progress='Progress percentage 0–100 (default 0)',
    image_url='Optional large image URL to display in the embed'
)
@app_commands.choices(
    status=[
        app_commands.Choice(name='🔄 Processing', value='Processing'),
        app_commands.Choice(name='⚙️ In Progress', value='In Progress'),
        app_commands.Choice(name='✅ Completed', value='Completed'),
    ],
    payment=[
        app_commands.Choice(name='💛 Binance', value='Binance'),
        app_commands.Choice(name='🔵 PayPal', value='PayPal'),
        app_commands.Choice(name='🏦 Bank Transfer', value='Bank Transfer'),
        app_commands.Choice(name='📱 UPI', value='UPI'),
        app_commands.Choice(name='🪙 Crypto Coin', value='Crypto Coin'),
        app_commands.Choice(name='💙 Paytm', value='Paytm'),
    ],
    target_completion=[
        app_commands.Choice(name='1d — 1 Day', value=1),
        app_commands.Choice(name='2d — 2 Days', value=2),
        app_commands.Choice(name='3d — 3 Days', value=3),
        app_commands.Choice(name='5d — 5 Days', value=5),
        app_commands.Choice(name='10d — 10 Days', value=10),
        app_commands.Choice(name='15d — 15 Days', value=15),
        app_commands.Choice(name='20d — 20 Days', value=20),
        app_commands.Choice(name='30d — 30 Days', value=30),
    ]
)
async def orderplaced_slash(
    interaction: discord.Interaction,
    customer: discord.Member,
    product: str,
    payment: str,
    target_completion: int,
    review_text: Optional[str] = None,
    rating: app_commands.Range[int, 1, 5] = 5,
    status: str = 'Processing',
    progress: app_commands.Range[int, 0, 100] = 0,
    image_url: Optional[str] = None
):
    if not interaction.guild:
        await interaction.response.send_message('This command can only be used in a server.', ephemeral=True)
        return

    if not is_staff(interaction.user):
        await interaction.response.send_message('❌ Only staff members can use this command.', ephemeral=True)
        return

    order_id = generate_order_id()
    while True:
        g = str(interaction.guild.id)
        existing = orders_db.get(g, [])
        if not any(o.get('order_id') == order_id for o in existing):
            break
        order_id = generate_order_id()

    embed = build_order_embed(
        guild=interaction.guild,
        customer=customer,
        product=product,
        payment=payment,
        target_completion=target_completion,
        status=status,
        progress=progress,
        order_id=order_id,
        review_text=review_text,
        rating=rating,
        image_url=image_url
    )

    order_channel = bot.get_channel(ORDER_CHANNEL_ID)
    msg_id = None
    if order_channel and isinstance(order_channel, discord.TextChannel):
        import os as _os
        if _os.path.exists(ORDER_THUMBNAIL_PATH):
            gif_file = discord.File(ORDER_THUMBNAIL_PATH, filename=ORDER_THUMBNAIL_FILENAME)
            order_msg = await order_channel.send(file=gif_file, embed=embed)
        else:
            order_msg = await order_channel.send(embed=embed)
        msg_id = order_msg.id
        confirm_text = (
            f'✅ Order placed successfully!\n'
            f'**Order ID:** `{order_id}`\n'
            f'**Customer:** {customer.mention}\n'
            f'**Product:** {product}\n'
            f'📋 Posted in {order_channel.mention}'
        )
    else:
        await interaction.response.send_message(embed=embed)
        confirm_text = f'✅ Order placed! **Order ID:** `{order_id}`'

    await interaction.response.send_message(confirm_text, ephemeral=True)

    orders_db.setdefault(g, [])
    orders_db[g].append({
        'order_id': order_id,
        'customer_id': customer.id,
        'product': product,
        'payment': payment,
        'review': review_text,
        'rating': rating,
        'status': status,
        'progress': progress,
        'target_completion_days': target_completion,
        'image_url': image_url,
        'placed_by': interaction.user.id,
        'guild_id': interaction.guild.id,
        'message_id': msg_id,
        'channel_id': ORDER_CHANNEL_ID,
        'timestamp': datetime.utcnow().isoformat()
    })
    save_json(ORDERS_FILE, orders_db)


async def ordercompleted_autocomplete(interaction: discord.Interaction, current: str):
    if not interaction.guild:
        return []
    g = str(interaction.guild.id)
    orders = orders_db.get(g, [])
    choices = []
    for o in orders:
        oid = o.get('order_id', '')
        if o.get('status') == 'Completed':
            continue
        if current.lower() in oid.lower() or current.lower() in o.get('product', '').lower():
            label = f"{oid} — {o.get('product', 'Unknown')}"
            choices.append(app_commands.Choice(name=label[:100], value=oid))
        if len(choices) >= 25:
            break
    return choices


@bot.tree.command(name='ordercompleted', description='Mark an order as complete and notify the customer (Staff only)')
@app_commands.describe(order_id='The unique Order ID (e.g. ORD-XXXXXXXX)')
@app_commands.autocomplete(order_id=ordercompleted_autocomplete)
async def ordercompleted_slash(interaction: discord.Interaction, order_id: str):
    if not interaction.guild:
        await interaction.response.send_message('This command can only be used in a server.', ephemeral=True)
        return

    if not is_staff(interaction.user):
        await interaction.response.send_message('❌ Only staff members can use this command.', ephemeral=True)
        return

    g = str(interaction.guild.id)
    orders = orders_db.get(g, [])
    order = next((o for o in orders if o.get('order_id') == order_id.upper()), None)

    if not order:
        await interaction.response.send_message(
            f'❌ No order found with ID `{order_id.upper()}`. Use autocomplete to pick a valid order.',
            ephemeral=True
        )
        return

    if order.get('status') == 'Completed':
        await interaction.response.send_message(
            f'⚠️ Order `{order_id.upper()}` is already marked as completed.',
            ephemeral=True
        )
        return

    order['status'] = 'Completed'
    order['progress'] = 100
    save_json(ORDERS_FILE, orders_db)

    try:
        customer = await interaction.guild.fetch_member(order['customer_id'])
    except Exception:
        customer = None

    if order.get('message_id') and order.get('channel_id'):
        try:
            ch = bot.get_channel(order['channel_id'])
            if ch:
                msg = await ch.fetch_message(order['message_id'])
                updated_embed = build_order_embed(
                    guild=interaction.guild,
                    customer=customer or discord.Object(id=order['customer_id']),
                    product=order.get('product', 'Unknown'),
                    payment=order.get('payment', 'Unknown'),
                    target_completion=order.get('target_completion_days', 1),
                    status='Completed',
                    progress=100,
                    order_id=order_id.upper(),
                    review_text=order.get('review'),
                    rating=order.get('rating', 5),
                    image_url=order.get('image_url')
                )
                import os as _os
                if _os.path.exists(ORDER_THUMBNAIL_PATH):
                    gif_file = discord.File(ORDER_THUMBNAIL_PATH, filename=ORDER_THUMBNAIL_FILENAME)
                    await msg.edit(embed=updated_embed, attachments=[gif_file])
                else:
                    await msg.edit(embed=updated_embed)
        except Exception:
            pass

    review_channel_link = f'https://discord.com/channels/{interaction.guild.id}/{REVIEW_CHANNEL_ID}'
    dm_sent = False
    if customer:
        try:
            dm_embed = discord.Embed(
                title='✅ Your Order is Complete!',
                description=(
                    f'Hey {customer.mention}! 🎉\n\n'
                    f'Your order **#{order_id.upper()}** for **{order.get("product", "your product")}** '
                    f'from **{interaction.guild.name}** has been completed!\n\n'
                    f'We\'d love to hear your feedback — please leave a review here:\n'
                    f'👉 [Click to leave your review]({review_channel_link})'
                ),
                color=0x00C851,
                timestamp=datetime.utcnow()
            )
            dm_embed.set_thumbnail(url=ORDER_THUMBNAIL_GIF)
            if interaction.guild.icon:
                dm_embed.set_author(name=interaction.guild.name, icon_url=interaction.guild.icon.url)
            dm_embed.set_footer(text='Thank you for your purchase! • Made by Tanish14')
            await customer.send(embed=dm_embed)
            dm_sent = True
        except discord.Forbidden:
            pass

    customer_str = customer.mention if customer else '<@' + str(order['customer_id']) + '>'
    dm_note = '📬 Customer has been notified via DM.' if dm_sent else '⚠️ Could not DM the customer (DMs may be closed).'
    completion_embed = discord.Embed(
        title='✅ Order Completed',
        description=(
            f'**Order ID:** `{order_id.upper()}`\n'
            f'**Product:** {order.get("product", "Unknown")}\n'
            f'**Customer:** {customer_str}\n'
            f'**Progress:** {make_progress_bar(100)}\n\n'
            f'{dm_note}'
        ),
        color=0x00C851,
        timestamp=datetime.utcnow()
    )
    completion_embed.set_footer(text=f'Completed by {interaction.user.display_name} • Made by Tanish14')
    await interaction.response.send_message(embed=completion_embed)


async def run_bot():
    retry_delay = 5
    max_delay = 300
    attempt = 0
    while True:
        try:
            attempt += 1
            print(f'🔄 Connecting to Discord... (attempt {attempt})')
            await bot.start(TOKEN)
        except discord.errors.LoginFailure:
            print('❌ Invalid DISCORD_TOKEN. Check your secret and restart.')
            break
        except (discord.errors.ConnectionClosed, discord.errors.GatewayNotFound,
                discord.errors.HTTPException) as e:
            print(f'⚠️ Connection error: {e}. Reconnecting in {retry_delay}s...')
        except Exception as e:
            print(f'⚠️ Unexpected error: {e}. Reconnecting in {retry_delay}s...')
        finally:
            if not bot.is_closed():
                await bot.close()
        print(f'⏳ Waiting {retry_delay}s before reconnect...')
        await asyncio.sleep(retry_delay)
        retry_delay = min(retry_delay * 2, max_delay)

if __name__ == '__main__':
    if not TOKEN:
        print('Error: DISCORD_TOKEN environment variable not set. Exiting.')
    else:
        keep_alive()
        print('🌐 Keep-alive server started on port 5000')
        print('💡 Tip: Add your Replit URL to UptimeRobot (free) to keep the bot online 24/7')
        asyncio.run(run_bot())
